package datuBasea;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;

public class DbKonexioa {

    // Librer�a de MySQL
    public static String driver = "com.mysql.cj.jdbc.Driver";

    // Nombre de la base de datos
    public String database = "";

    // Host
    public String hostname = "";

    // Puerto
    public String port = "";

    // Ruta de nuestra base de datos (desactivamos el uso de SSL con "?useSSL=false")
    public static String url = "";
    
    public static String dUrl ="";
    // Nombre de usuario
    public static String username = "";

    // Clave de usuario
    public static String password = "";
    

    public DbKonexioa(String pdat, String phost, String pPort, String user, String pass) {
    	database = pdat;
    	hostname = phost;
    	port = pPort;
    	username = user;
    	password = pass;
    	url = "jdbc:mysql://" + hostname + ":" + port + "/" + database + "?useSSL=false";
    	dUrl = "jdbc:mysql://" + hostname + ":" + port;
    }
    
    private static void createDatabase() {
    	try(
    		Connection conn = DriverManager.getConnection(dUrl, username, password);
    	    Statement stmt = conn.createStatement();
    			
    	      ) {		      
    	         String sql = "CREATE DATABASE conntest";
    	         stmt.executeUpdate(sql);
    	         createTaulak(DriverManager.getConnection(url, username, password));
    	         System.out.println("Database created successfully..."); 
    	         conn.close();
    	      } catch (SQLException e) {
    	         e.printStackTrace();

    	      } catch(com.mysql.cj.exceptions.CJCommunicationsException e) {
    	    	  System.out.println("EY");
    	    	  System.out.println("EY");
    	    	  System.out.println("EY");
    	    	  System.out.println("EY");
    	    	  System.out.println("EY");
    	      }
    		
    }
    
    private static void createTaulak(Connection conn) {
    	try {
    		Statement stmt = conn.createStatement();
    		// SQL command to create a database in MySQL.
    		
   		 //CREATE TABLE IF NOT EXISTS GAIXOA ( kodea int not null, JData date, PRIMARY KEY (kodea) )

   		 //CREATE TABLE IF NOT EXISTS SENTSOREMOTA ( kodea int not null, izena varchar(80), PRIMARYKEY (kodea) )

   		 //CREATE TABLE IF NOT EXISTS ITURRIA ( kodea int not null, izena varchar(80),PRIMARY KEY (kodea) )

   		 //CREATE TABLE IF NOT EXISTS GERTAERA ( kodea int not null, izena varchar(80), deskribapena  varchar(200), PRIMARY KEY (kodea) )

   		 //CREATE TABLE IF NOT EXISTS SENTSOREA ( kodea int not null, izena varchar(80), azalpena varchar(200), unitatea varchar(80), min int, max int, sMota int not null, PRIMARY KEY (kodea), FOREIGN KEY (smota) REFERENCES SentsoreMota(kodea) )

   		 //CREATE TABLE IF NOT EXISTS PROBA ( gaKodea varchar(80) not null, pData datetime not null, hasiera datetime, bukaera datetime, PRIMARY KEY (gaKodea, pData), FOREIGN KEY (gaKodea) REFERENCES Gaixoa(kodea) )

   		 //CREATE TABLE IF NOT EXISTS PDAUKASENS ( gaKodea varchar(80) not null, pData datetime not null, sKodea int not null, denboraMarka int, datua int, PRIMARY KEY (gaKodea, pData, sKodea), FOREIGN KEY (gaKodea, pData) REFERENCES Proba(gaKodea, pData) )

   		 //CREATE TABLE IF NOT EXISTS DAUKA ( iKodea int not null, gaKodea varchar(80) not null, pData datetime not null, sKodea int not null, geKodea int not null, PRIMARY KEY (geKodea), FOREIGN KEY (gaKodea, pData) REFERENCES Proba(gaKodea, pData), FOREIGN KEY (iKodea) REFERENCES Iturria(kodea), FOREIGN KEY (sKodea) REFERENCES Sentsorea(kodea), FOREIGN KEY (geKodea) REFERENCES Gertaera(kodea) )

   		 //CREATE TABLE IF NOT EXISTS NOLANEURTU ( sKodea int not null, geKodea int not null, PRIMARY KEY (geKodea, sKodea), FOREIGN KEY (sKodea) REFERENCES Sentsorea(kodea),FOREIGN KEY (geKodea) REFERENCES Gertaera(kodea) )

   		 
       	
       	String sql = "";
       	
       	sql = "CREATE TABLE IF NOT EXISTS GAIXOA ( "
       			+ "kodea varchar(80) not null, JData date, PRIMARY KEY (kodea) "
       			+ ")";
       	//System.out.println(sql);
       	stmt.executeUpdate(sql);

       	sql = "CREATE TABLE IF NOT EXISTS SENTSOREMOTA ( kodea varchar(80) not null, izena varchar(80), PRIMARY KEY (kodea) )";
       	//System.out.println(sql);
       	stmt.executeUpdate(sql);

    	sql ="CREATE TABLE IF NOT EXISTS ITURRIA ( "
       			+ "kodea int not null, izena varchar(80),PRIMARY KEY (kodea) "
       			+ ")";
    	//System.out.println(sql);
       	stmt.executeUpdate(sql);

       	sql ="CREATE TABLE IF NOT EXISTS GERTAERA ( "
       			+ "kodea int not null, izena varchar(80), deskribapena  varchar(200), PRIMARY KEY (kodea) "
       			+ ")";
       	//System.out.println(sql);
       	stmt.executeUpdate(sql);

       	sql ="CREATE TABLE IF NOT EXISTS SENTSOREA ( "
       			+ "kodea int not null, izena varchar(80), azalpena varchar(200), unitatea varchar(80), min int, max int, sMota varchar(80) not null, PRIMARY KEY (kodea), "
       			+ "FOREIGN KEY (sMota) REFERENCES SentsoreMota(kodea) "
       			+ ")";
       	//System.out.println(sql);
       	stmt.executeUpdate(sql);

       	sql ="CREATE TABLE IF NOT EXISTS PROBA ( "
       			+ "gaKodea varchar(80) not null, pData datetime not null, hasiera datetime, bukaera datetime, PRIMARY KEY (gaKodea, pData), FOREIGN KEY (gaKodea) REFERENCES Gaixoa(kodea) "
       			+ ")";
       	//System.out.println(sql);
       	stmt.executeUpdate(sql);
       	//TODO gertaera = foreign key gisa sartu, erregistratutako gertaera izan behar da
       	sql ="CREATE TABLE IF NOT EXISTS DATUAK ( "
       			+ "gaKodea varchar(80) not null, pData datetime not null, sKodea int not null, denboraMarka int not null, datua int, gertaera int, PRIMARY KEY (gaKodea, pData, sKodea, denboraMarka), "
       			+ "FOREIGN KEY (gaKodea, pData) REFERENCES Proba(gaKodea, pData), "
       			+ "FOREIGN KEY (sKodea) references sentsorea (kodea)"
       			
       			+ ")";
       	//System.out.println(sql);
       	stmt.executeUpdate(sql);
/*
 CREATE TABLE IF NOT EXISTS DAUKA ( 
iKodea int not null, 
gaKodea varchar(80) not null, 
pData datetime not null, 
sKodea int not null, 
geKodea int not null, 
dMarka int not null, 
PRIMARY KEY (geKodea, gaKodea, sKodea, iKodea,pData,dMarka), 
FOREIGN KEY (gaKodea, pData) REFERENCES Proba(gaKodea, pData), 
FOREIGN KEY (iKodea) REFERENCES Iturria(kodea), 
FOREIGN KEY (sKodea) REFERENCES Sentsorea(kodea), 
FOREIGN KEY (geKodea) REFERENCES Gertaera(kodea), 
Foreign key (dMarka) references datuak(denboraMarka) )
 */
       	sql ="CREATE TABLE IF NOT EXISTS DAUKA ( "
       			+ "iKodea int not null, gaKodea varchar(80) not null, pData datetime not null, sKodea int not null, geKodea int not null, dMarka int not null, PRIMARY KEY (geKodea, gaKodea, sKodea, iKodea,pData,dMarka), "
       			+ "FOREIGN KEY (gaKodea, pData) REFERENCES Proba(gaKodea, pData), FOREIGN KEY (iKodea) REFERENCES Iturria(kodea), "
       			+ "FOREIGN KEY (sKodea) REFERENCES Sentsorea(kodea), FOREIGN KEY (geKodea) REFERENCES Gertaera(kodea) )";
       	System.out.println(sql);
       	stmt.executeUpdate(sql);
       	
       	sql ="CREATE TABLE IF NOT EXISTS NOLANEURTU ( sKodea int not null, geKodea int not null, PRIMARY KEY (geKodea, sKodea), "
       			+ "FOREIGN KEY (sKodea) REFERENCES Sentsorea(kodea),FOREIGN KEY (geKodea) REFERENCES Gertaera(kodea) "
       			+ ")";
       	//System.out.println(sql);
       	
       	stmt.executeUpdate(sql);
       	
  		 //CREATE TABLE IF NOT EXISTS PDAUKASENS ( gaKodea varchar(80) not null, pData datetime not null, sKodea int not null, denboraMarka int, datua int, PRIMARY KEY (gaKodea, pData, sKodea), FOREIGN KEY (gaKodea, pData) REFERENCES Proba(gaKodea, pData) )
/*
       	sql = "CREATE TABLE IF NOT EXISTS PDAUKASENS ( gaKodea varchar(80) not null, pData datetime not null, sKodea int not null, "
       			+ "denboraMarka int, datua int, "
       			+ "PRIMARY KEY (gaKodea, pData, sKodea), FOREIGN KEY (gaKodea, pData) REFERENCES Proba(gaKodea, pData) )";
       	//System.out.println(sql);
       	stmt.executeUpdate(sql);
       	*/
       	
       	
       	
       	
       	
       	
       	// constatnt INSERTS:
       		//Iturria
     	sql ="Insert into iturria values (0,'Sistema')";       	
       	stmt.executeUpdate(sql);
       	sql ="Insert into iturria values (1,'Aditua')";       	
       	stmt.executeUpdate(sql);
       		//SentsoreMota
       	sql ="Insert into SentsoreMota values ('ER', 'Esfuerzo Respiratorio')";       	
       	stmt.executeUpdate(sql);
       	sql ="Insert into SentsoreMota values ('FR', 'Flujo Respiratorio')";       	
       	stmt.executeUpdate(sql);
       	sql ="Insert into SentsoreMota values ('PO', 'Posicion y movimiento')";       	
       	stmt.executeUpdate(sql);
       	sql ="Insert into SentsoreMota values ('DO', 'Desaturacion de oxigeno')";       	
       	stmt.executeUpdate(sql);
       	sql ="Insert into SentsoreMota values ('SO', 'Sonido')";       	
       	stmt.executeUpdate(sql);
       	sql ="Insert into SentsoreMota values ('OTRO', 'Sensor inprevisto')";       	
       	stmt.executeUpdate(sql);
       	
       		//Gertaera
    	sql ="Insert into Gertaera values (0, 'Respiracion paradogica','placeholder')";       	
       	stmt.executeUpdate(sql);
    	sql ="Insert into Gertaera values (4, 'Desaturacion','placeholder')";       	
       	stmt.executeUpdate(sql);
    	sql ="Insert into Gertaera values (1, 'Ronquido','placeholder')";       	
       	stmt.executeUpdate(sql);
    	sql ="Insert into Gertaera values (5, 'Hipoapnea','placeholder')";       	
       	stmt.executeUpdate(sql);
    	sql ="Insert into Gertaera values (2, 'Serie de ronquidos','placeholder')";       	
       	stmt.executeUpdate(sql);
    	sql ="Insert into Gertaera values (3, 'Movimiento','placeholder')";       	
       	stmt.executeUpdate(sql);
    	sql ="Insert into Gertaera values (6, 'Apnea Central','placeholder')";       	
       	stmt.executeUpdate(sql);
    	sql ="Insert into Gertaera values (7, 'Apnea Mixta','placeholder')";       	
       	stmt.executeUpdate(sql);
       	sql ="Insert into Gertaera values (8, 'Artefacto','placeholder')";       	
       	stmt.executeUpdate(sql);
       	sql ="Insert into Gertaera values (9, 'Taquicardia','placeholder')";       	
       	stmt.executeUpdate(sql);
       	
       	
       	
       	
       	
       	
       	
       	
       	
       	
       	
       	
       	
       	//System.out.println("Ok Tables");
       	/*
       	CREATE TRIGGER <identifikatzailea>
       	{ AFTER | BEFORE | INSTEAD OF }
       	{ INSERT | DELETE | UPDATE [OF (<atrib> (, <atrib>)*) ] } 
       	 ON {<taula> | <bista>}
       	[ FOR EACH ROW | STATEMENT ]
       	[ REFERENCING OLD AS <izena> NEW AS <izena> ]
       	[ REFERENCING OLD_TABLE AS <izena> NEW_TABLE AS <izena> ]
       	[ WHEN <baldintza> ]
       	<DBren gaineko ekintza-segida>
       	<biltegiratutako prozedura bati egindako deia>
       	<kanpoko funtzio bati egindako deia>
       	
       Create trigger DaukaBete 
after update of (gertaera) on datuak
for each row
begin
if exists(select * from datuak where NEW.gertaera is not null)
          insert into dauka values('1','gaKodea','pData','sKodea','NEW.gertaera')
       	*/
       	
       	
/*
 Create trigger DaukaBete 
after update of (gertaera) on datuak
for each row
begin
if exists(select * from datuak where gertaera is not null)
then
	insert into dauka values(1,:NEW.gaKodea,:NEW.pData,:NEW.sKodea,:NEW.gertaera)
	
	
	
	
	Create trigger DaukaBete 
after update of (gertaera) on datuak
for each row
begin
	if exists(NEW.gertaera is not null) THEN
    	insert into dauka values('1',:NEW.gaKodea,:NEW.pData,:NEW.sKodea,:NEW.gertaera)
    	
CREATE TRIGGER before_employee_update 
    BEFORE UPDATE ON datuak
    FOR EACH ROW 
 INSERT INTO dauka
 SET 
 	 gaKodea = OLD.gaKodea,
     geKodea = NEW.gertaera,
     iKodea = 1,
     pData = OLD.pData,
     sKodea = OLD.sKodea,
     dMarka = OLD.denboraMarka;
 */

    	sql ="CREATE TRIGGER before_employee_update \r\n"
    			+ "    BEFORE UPDATE ON datuak\r\n"
    			+ "    FOR EACH ROW \r\n"
    			+ " INSERT INTO dauka\r\n"
    			+ " SET \r\n"
    			+ " 	 gaKodea = OLD.gaKodea,\r\n"
    			+ "     geKodea = NEW.gertaera,\r\n"
    			+ "     iKodea = 1,\r\n"
    			+ "     pData = OLD.pData,\r\n"
    			+ "     sKodea = OLD.sKodea,\r\n"
    			+ "		dMarka = OLD.denboraMarka;";       	
       	stmt.executeUpdate(sql);
       	
       	conn.close();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    private static boolean conectarMySQL(){
        Connection conn = null;
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(dUrl, username, password);
            conn.close();
            return true;
        } catch (ClassNotFoundException e) {
        	e.printStackTrace();
        	System.out.println("Class not found, please install " + driver);
            return false;
        } catch (SQLException e) {
        	e.printStackTrace();
        	System.out.println("Couldn't connect to SQL");
        	return false;
        }
        
    }
    
    public static Connection conectarDatabase() {
    	
    		try {
    			Connection conn = null;
    	    	if(conectardb()) {
	            	conn = DriverManager.getConnection(url, username, password);
	            	//System.out.println("connected to database");
	            	return conn;
    	    	}
    	    	else {
    	    		checkdbexists();
    	    		//if(!checkdbexists()) {
    	    			
    	    		//}
    	    		return conectarDatabase();
    	    	}
            }catch(SQLException e) {
    			//System.out.println("database doesn't exist");
            	//System.out.println("Creating database");
            	//createDatabase();
            	return conectarDatabase();
			}
    }
    
	private static boolean checkdbexists() {
		try {
			Connection conn = DriverManager.getConnection(dUrl, username, password); //Open a connection
		    
			ResultSet resultSet = conn.getMetaData().getCatalogs();

			//iterate each catalog in the ResultSet
			while (resultSet.next()) {
			  // Get the database name, which is at position 1
			  String databaseName = resultSet.getString(1);
			  if(databaseName.equals("conntest")){
	                return true;
	          }
			}
			resultSet.close();
			createDatabase();
			return false;
		}catch(SQLException e) {
			return false;
		}
		
	}

	private static boolean conectardb() {
		Connection conn = null;
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, username, password);
			conn.close();
			return true;
		} catch (ClassNotFoundException e) {
			//e.printStackTrace();
			System.out.println("Class not found, please install " + driver);
			return false;
		} catch (SQLException e) {
			//e.printStackTrace();
			//System.out.println("Couldn't connect to SQL");
			return false;

		}

	}
}

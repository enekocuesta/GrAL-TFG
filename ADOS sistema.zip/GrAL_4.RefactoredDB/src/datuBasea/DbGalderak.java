package datuBasea;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class DbGalderak {

	
	public static boolean sendUpdate(String s) {
		try {
			DbKonexioa con = new DbKonexioa("conntest", "localhost", "3306", "root", "");
			Connection c = con.conectarDatabase();
			Statement st;
			st = c.createStatement();
			st.executeUpdate(s);
			c.close();
			//System.out.println("Query: "+s);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
	}
	public static boolean sendQuery(String s) {
		try {
			DbKonexioa con = new DbKonexioa("conntest", "localhost", "3306", "root", "");
			Connection c = con.conectarDatabase();
			Statement st;
			st = c.createStatement();
			st.executeQuery(s);
			c.close();
			//System.out.println("Query: "+s);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
	}

	public static ArrayList<ArrayList<String>> sendWithReturnArray(String s) {
		//Konektatu
		
		DbKonexioa con = new DbKonexioa("conntest", "localhost", "3306", "root", "");
		Connection c = con.conectarDatabase();
		
		//Hasieraketak
		ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();
		ArrayList<String> row = new ArrayList<String>(); //Hasieratu 
		Statement st;
		
		try {
			//Galdera egin
			st = c.createStatement();
			ResultSet rs = st.executeQuery(s);
			
			//Zutabe kopurua lortu
			ResultSetMetaData metadata = rs.getMetaData();
			int columnCount = metadata.getColumnCount();
			
			//Lerro bakoitzeko
			while (rs.next()) { 
				for (int i = 1; i <= columnCount; i++) {
					row.add(rs.getString(i)); //Gehitu zutabea
				}
				result.add(row); //Gehitu lerroa
				row = new ArrayList<String>();
			}
			
			c.close();
			System.out.println("Query: "+s);
			return result;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
			return null;
		}
	}
	public static boolean exists(String s) {
		// TODO Auto-generated method stub
		DbKonexioa con = new DbKonexioa("conntest", "localhost", "3306", "root", "");
		Connection c = con.conectarDatabase();
		Statement st;
		try {
			st = c.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = st.executeQuery(s);
			int size=0;
			if (rs != null) 
			{
			  rs.last();    // moves cursor to the last row
			  size = rs.getRow(); // get row id 
			}
			
			c.close();
			System.out.println("Query: "+s);
			return (size != 0); //returns false if size is greater than 0, ergo if it doesn't exist
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
	}
}

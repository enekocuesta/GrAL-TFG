package gui;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.GridBagLayout;
import javax.swing.JRadioButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.JCheckBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.FlowLayout;

public class ParameterSelectPopUp extends JFrame {

	private JPanel contentPane;
	ArrayList<String> selectedParameters = new ArrayList<String>();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ParameterSelectPopUp frame = new ParameterSelectPopUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ParameterSelectPopUp() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 966, 588);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 19, 3, 35, 0, -10, 0, -8, 0, 189, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0};
		gbl_panel.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		//Flujo respiratorio
		JList list_FR = new JList();
		GridBagConstraints gbc_list_FR = new GridBagConstraints();
		gbc_list_FR.insets = new Insets(0, 0, 5, 5);
		gbc_list_FR.fill = GridBagConstraints.BOTH;
		gbc_list_FR.gridx = 2;
		gbc_list_FR.gridy = 1;
		
		JCheckBox flujoRespiratorio = new JCheckBox("Flujo Respiratorio");
		flujoRespiratorio.setHorizontalAlignment(SwingConstants.LEFT);
		flujoRespiratorio.setForeground(Color.BLACK);
		flujoRespiratorio.setBackground(SystemColor.info);
		GridBagConstraints gbc_flujoRespiratorio = new GridBagConstraints();
		gbc_flujoRespiratorio.anchor = GridBagConstraints.WEST;
		gbc_flujoRespiratorio.insets = new Insets(0, 0, 5, 5);
		gbc_flujoRespiratorio.gridx = 1;
		gbc_flujoRespiratorio.gridy = 1;
		panel.add(flujoRespiratorio, gbc_flujoRespiratorio);
		
		JCheckBox esfuerzoRespiratorio = new JCheckBox("Esfuerzo Respiratorio");
		esfuerzoRespiratorio.setHorizontalAlignment(SwingConstants.LEFT);
		esfuerzoRespiratorio.setForeground(Color.BLACK);
		esfuerzoRespiratorio.setBackground(SystemColor.info);
		GridBagConstraints gbc_esfuerzoRespiratorio = new GridBagConstraints();
		gbc_esfuerzoRespiratorio.anchor = GridBagConstraints.WEST;
		gbc_esfuerzoRespiratorio.insets = new Insets(0, 0, 5, 5);
		gbc_esfuerzoRespiratorio.gridx = 3;
		gbc_esfuerzoRespiratorio.gridy = 1;
		panel.add(esfuerzoRespiratorio, gbc_esfuerzoRespiratorio);
		
		JCheckBox PosicionMovimiento = new JCheckBox("Posicion y movimiento");
		PosicionMovimiento.setHorizontalAlignment(SwingConstants.LEFT);
		PosicionMovimiento.setForeground(Color.BLACK);
		PosicionMovimiento.setBackground(SystemColor.info);
		GridBagConstraints gbc_PosicionMovimiento = new GridBagConstraints();
		gbc_PosicionMovimiento.anchor = GridBagConstraints.WEST;
		gbc_PosicionMovimiento.insets = new Insets(0, 0, 5, 5);
		gbc_PosicionMovimiento.gridx = 5;
		gbc_PosicionMovimiento.gridy = 1;
		panel.add(PosicionMovimiento, gbc_PosicionMovimiento);
		
		JCheckBox DesaturacionOxigeno = new JCheckBox("Desaturacion de Oxigeno");
		DesaturacionOxigeno.setHorizontalAlignment(SwingConstants.LEFT);
		DesaturacionOxigeno.setForeground(Color.BLACK);
		DesaturacionOxigeno.setBackground(SystemColor.info);
		GridBagConstraints gbc_DesaturacionOxigeno = new GridBagConstraints();
		gbc_DesaturacionOxigeno.anchor = GridBagConstraints.WEST;
		gbc_DesaturacionOxigeno.insets = new Insets(0, 0, 5, 5);
		gbc_DesaturacionOxigeno.gridx = 7;
		gbc_DesaturacionOxigeno.gridy = 1;
		panel.add(DesaturacionOxigeno, gbc_DesaturacionOxigeno);
		
		JCheckBox SonidoBig = new JCheckBox("Sonido");
		SonidoBig.setHorizontalAlignment(SwingConstants.LEFT);
		SonidoBig.setForeground(Color.BLACK);
		SonidoBig.setBackground(SystemColor.info);
		GridBagConstraints gbc_SonidoBig = new GridBagConstraints();
		gbc_SonidoBig.anchor = GridBagConstraints.WEST;
		gbc_SonidoBig.insets = new Insets(0, 0, 5, 5);
		gbc_SonidoBig.gridx = 9;
		gbc_SonidoBig.gridy = 1;
		panel.add(SonidoBig, gbc_SonidoBig);
		
		JPanel panel_1 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel_1.getLayout();
		flowLayout.setVgap(1);
		flowLayout.setHgap(1);
		panel_1.setBackground(SystemColor.desktop);
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.anchor = GridBagConstraints.NORTH;
		gbc_panel_1.gridwidth = 11;
		gbc_panel_1.insets = new Insets(0, 0, 5, 0);
		gbc_panel_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 2;
		panel.add(panel_1, gbc_panel_1);

			//Fase RIP
		JCheckBox Fase_RIP = new JCheckBox("Fase RIP");
		Fase_RIP.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_Fase_RIP = new GridBagConstraints();
		gbc_Fase_RIP.anchor = GridBagConstraints.WEST;
		gbc_Fase_RIP.insets = new Insets(0, 0, 5, 5);
		gbc_Fase_RIP.gridx = 1;
		gbc_Fase_RIP.gridy = 3;
		panel.add(Fase_RIP, gbc_Fase_RIP);
		
			//Flujo RIP
		JCheckBox Flujo_RIP = new JCheckBox("Flujo RIP");
		Flujo_RIP.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_Flujo_RIP = new GridBagConstraints();
		gbc_Flujo_RIP.anchor = GridBagConstraints.WEST;
		gbc_Flujo_RIP.insets = new Insets(0, 0, 5, 5);
		gbc_Flujo_RIP.gridx = 1;
		gbc_Flujo_RIP.gridy = 4;
		panel.add(Flujo_RIP, gbc_Flujo_RIP);
		
		JCheckBox SpO2BB = new JCheckBox("SpO2 BB");
		SpO2BB.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_SpO2BB = new GridBagConstraints();
		gbc_SpO2BB.anchor = GridBagConstraints.WEST;
		gbc_SpO2BB.insets = new Insets(0, 0, 5, 5);
		gbc_SpO2BB.gridx = 7;
		gbc_SpO2BB.gridy = 4;
		panel.add(SpO2BB, gbc_SpO2BB);
		
		JCheckBox Suma_RIP = new JCheckBox("Suma RIP");
		Suma_RIP.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_Suma_RIP = new GridBagConstraints();
		gbc_Suma_RIP.anchor = GridBagConstraints.WEST;
		gbc_Suma_RIP.insets = new Insets(0, 0, 5, 5);
		gbc_Suma_RIP.gridx = 1;
		gbc_Suma_RIP.gridy = 5;
		panel.add(Suma_RIP, gbc_Suma_RIP);
		

		JCheckBox Temp = new JCheckBox("Temp");
		Temp.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_Temp = new GridBagConstraints();
		gbc_Temp.anchor = GridBagConstraints.WEST;
		gbc_Temp.insets = new Insets(0, 0, 5, 5);
		gbc_Temp.gridx = 1;
		gbc_Temp.gridy = 7;
		panel.add(Temp, gbc_Temp);
		
		JCheckBox Pletismografo = new JCheckBox("Pletismografo");
		Pletismografo.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_Pletismografo = new GridBagConstraints();
		gbc_Pletismografo.anchor = GridBagConstraints.WEST;
		gbc_Pletismografo.insets = new Insets(0, 0, 5, 5);
		gbc_Pletismografo.gridx = 1;
		gbc_Pletismografo.gridy = 6;
		panel.add(Pletismografo, gbc_Pletismografo);
		
		JCheckBox Temp_FIR_LP_8H = new JCheckBox("Temp_FIR LP_8H ");
		Temp_FIR_LP_8H.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_Temp_FIR_LP_8H = new GridBagConstraints();
		gbc_Temp_FIR_LP_8H.anchor = GridBagConstraints.WEST;
		gbc_Temp_FIR_LP_8H.insets = new Insets(0, 0, 5, 5);
		gbc_Temp_FIR_LP_8H.gridx = 1;
		gbc_Temp_FIR_LP_8H.gridy = 8;
		panel.add(Temp_FIR_LP_8H, gbc_Temp_FIR_LP_8H);
		
		JCheckBox Temp_FIR_LP_7H = new JCheckBox("Temp_FIR LP_7H");
		Temp_FIR_LP_7H.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_Temp_FIR_LP_7H = new GridBagConstraints();
		gbc_Temp_FIR_LP_7H.anchor = GridBagConstraints.WEST;
		gbc_Temp_FIR_LP_7H.insets = new Insets(0, 0, 5, 5);
		gbc_Temp_FIR_LP_7H.gridx = 1;
		gbc_Temp_FIR_LP_7H.gridy = 9;
		panel.add(Temp_FIR_LP_7H, gbc_Temp_FIR_LP_7H);
		
		JCheckBox Temp_FIR_LP_2H = new JCheckBox("Temp_FIR LP_2H");
		Temp_FIR_LP_2H.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_Temp_FIR_LP_2H = new GridBagConstraints();
		gbc_Temp_FIR_LP_2H.anchor = GridBagConstraints.WEST;
		gbc_Temp_FIR_LP_2H.insets = new Insets(0, 0, 5, 5);
		gbc_Temp_FIR_LP_2H.gridx = 1;
		gbc_Temp_FIR_LP_2H.gridy = 10;
		panel.add(Temp_FIR_LP_2H, gbc_Temp_FIR_LP_2H);
		
		JCheckBox Abdomen = new JCheckBox("Abdomen");
		GridBagConstraints gbc_Abdomen = new GridBagConstraints();
		gbc_Abdomen.anchor = GridBagConstraints.WEST;
		gbc_Abdomen.insets = new Insets(0, 0, 5, 5);
		gbc_Abdomen.gridx = 3;
		gbc_Abdomen.gridy = 3;
		panel.add(Abdomen, gbc_Abdomen);
		
		JCheckBox Frecuencia_Respiratoria = new JCheckBox("Frecuencia Respiratoria");
		GridBagConstraints gbc_Frecuencia_Respiratoria = new GridBagConstraints();
		gbc_Frecuencia_Respiratoria.anchor = GridBagConstraints.WEST;
		gbc_Frecuencia_Respiratoria.insets = new Insets(0, 0, 5, 5);
		gbc_Frecuencia_Respiratoria.gridx = 3;
		gbc_Frecuencia_Respiratoria.gridy = 4;
		panel.add(Frecuencia_Respiratoria, gbc_Frecuencia_Respiratoria);
		
		JCheckBox Pulso = new JCheckBox("Pulso");
		GridBagConstraints gbc_Pulso = new GridBagConstraints();
		gbc_Pulso.anchor = GridBagConstraints.WEST;
		gbc_Pulso.insets = new Insets(0, 0, 5, 5);
		gbc_Pulso.gridx = 3;
		gbc_Pulso.gridy = 5;
		panel.add(Pulso, gbc_Pulso);
		
		JCheckBox Torax = new JCheckBox("Torax");
		GridBagConstraints gbc_Torax = new GridBagConstraints();
		gbc_Torax.anchor = GridBagConstraints.WEST;
		gbc_Torax.insets = new Insets(0, 0, 5, 5);
		gbc_Torax.gridx = 3;
		gbc_Torax.gridy = 6;
		panel.add(Torax, gbc_Torax);
		
		JCheckBox Presion_de_mascara = new JCheckBox("Presion de mascara");
		GridBagConstraints gbc_Presion_de_mascara = new GridBagConstraints();
		gbc_Presion_de_mascara.anchor = GridBagConstraints.WEST;
		gbc_Presion_de_mascara.insets = new Insets(0, 0, 5, 5);
		gbc_Presion_de_mascara.gridx = 3;
		gbc_Presion_de_mascara.gridy = 7;
		panel.add(Presion_de_mascara, gbc_Presion_de_mascara);
		
		JCheckBox EjeX = new JCheckBox("Eje X");
		GridBagConstraints gbc_EjeX = new GridBagConstraints();
		gbc_EjeX.anchor = GridBagConstraints.WEST;
		gbc_EjeX.insets = new Insets(0, 0, 5, 5);
		gbc_EjeX.gridx = 5;
		gbc_EjeX.gridy = 3;
		panel.add(EjeX, gbc_EjeX);
		
		JCheckBox EjeY = new JCheckBox("Eje Y");
		GridBagConstraints gbc_EjeY = new GridBagConstraints();
		gbc_EjeY.anchor = GridBagConstraints.WEST;
		gbc_EjeY.insets = new Insets(0, 0, 5, 5);
		gbc_EjeY.gridx = 5;
		gbc_EjeY.gridy = 4;
		panel.add(EjeY, gbc_EjeY);
		
		JCheckBox EjeZ = new JCheckBox("Eje Z");
		GridBagConstraints gbc_EjeZ = new GridBagConstraints();
		gbc_EjeZ.anchor = GridBagConstraints.WEST;
		gbc_EjeZ.insets = new Insets(0, 0, 5, 5);
		gbc_EjeZ.gridx = 5;
		gbc_EjeZ.gridy = 5;
		panel.add(EjeZ, gbc_EjeZ);
		
		JCheckBox Posicion = new JCheckBox("Posicion");
		GridBagConstraints gbc_Posicion = new GridBagConstraints();
		gbc_Posicion.anchor = GridBagConstraints.WEST;
		gbc_Posicion.insets = new Insets(0, 0, 5, 5);
		gbc_Posicion.gridx = 5;
		gbc_Posicion.gridy = 6;
		panel.add(Posicion, gbc_Posicion);
		
		JCheckBox Elevacion = new JCheckBox("Elevacion");
		GridBagConstraints gbc_Elevacion = new GridBagConstraints();
		gbc_Elevacion.anchor = GridBagConstraints.WEST;
		gbc_Elevacion.insets = new Insets(0, 0, 5, 5);
		gbc_Elevacion.gridx = 5;
		gbc_Elevacion.gridy = 7;
		panel.add(Elevacion, gbc_Elevacion);
		
		JCheckBox Actividad = new JCheckBox("Actividad");
		GridBagConstraints gbc_Actividad = new GridBagConstraints();
		gbc_Actividad.anchor = GridBagConstraints.WEST;
		gbc_Actividad.insets = new Insets(0, 0, 5, 5);
		gbc_Actividad.gridx = 5;
		gbc_Actividad.gridy = 8;
		panel.add(Actividad, gbc_Actividad);
		
		JCheckBox SpO2 = new JCheckBox("SpO2");
		GridBagConstraints gbc_SpO2 = new GridBagConstraints();
		gbc_SpO2.anchor = GridBagConstraints.WEST;
		gbc_SpO2.insets = new Insets(0, 0, 5, 5);
		gbc_SpO2.gridx = 7;
		gbc_SpO2.gridy = 3;
		panel.add(SpO2, gbc_SpO2);
		
		JCheckBox Audio = new JCheckBox("Volumen de Audio");
		GridBagConstraints gbc_Audio = new GridBagConstraints();
		gbc_Audio.anchor = GridBagConstraints.WEST;
		gbc_Audio.insets = new Insets(0, 0, 5, 5);
		gbc_Audio.gridx = 9;
		gbc_Audio.gridy = 3;
		panel.add(Audio, gbc_Audio);
		
		JCheckBox Sonido = new JCheckBox("Volumen de Sonido");
		GridBagConstraints gbc_Sonido = new GridBagConstraints();
		gbc_Sonido.anchor = GridBagConstraints.WEST;
		gbc_Sonido.insets = new Insets(0, 0, 5, 5);
		gbc_Sonido.gridx = 9;
		gbc_Sonido.gridy = 4;
		panel.add(Sonido, gbc_Sonido);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(SystemColor.desktop);
		FlowLayout flowLayout_1 = (FlowLayout) panel_2.getLayout();
		flowLayout_1.setHgap(1);
		flowLayout_1.setVgap(1);
		GridBagConstraints gbc_panel_2 = new GridBagConstraints();
		gbc_panel_2.fill = GridBagConstraints.VERTICAL;
		gbc_panel_2.gridheight = 9;
		gbc_panel_2.insets = new Insets(0, 0, 5, 5);
		gbc_panel_2.gridx = 2;
		gbc_panel_2.gridy = 3;
		panel.add(panel_2, gbc_panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(SystemColor.desktop);
		FlowLayout flowLayout_2 = (FlowLayout) panel_3.getLayout();
		flowLayout_2.setVgap(1);
		flowLayout_2.setHgap(1);
		GridBagConstraints gbc_panel_3 = new GridBagConstraints();
		gbc_panel_3.gridheight = 9;
		gbc_panel_3.insets = new Insets(0, 0, 5, 5);
		gbc_panel_3.fill = GridBagConstraints.VERTICAL;
		gbc_panel_3.gridx = 4;
		gbc_panel_3.gridy = 3;
		panel.add(panel_3, gbc_panel_3);
		
		JPanel panel_4 = new JPanel();
		FlowLayout flowLayout_4 = (FlowLayout) panel_4.getLayout();
		flowLayout_4.setHgap(1);
		flowLayout_4.setVgap(1);
		panel_4.setBackground(SystemColor.desktop);
		GridBagConstraints gbc_panel_4 = new GridBagConstraints();
		gbc_panel_4.gridheight = 9;
		gbc_panel_4.insets = new Insets(0, 0, 5, 5);
		gbc_panel_4.fill = GridBagConstraints.VERTICAL;
		gbc_panel_4.gridx = 6;
		gbc_panel_4.gridy = 3;
		panel.add(panel_4, gbc_panel_4);
		
		JPanel panel_5 = new JPanel();
		FlowLayout flowLayout_3 = (FlowLayout) panel_5.getLayout();
		flowLayout_3.setHgap(1);
		flowLayout_3.setVgap(1);
		panel_5.setBackground(SystemColor.desktop);
		GridBagConstraints gbc_panel_5 = new GridBagConstraints();
		gbc_panel_5.gridheight = 9;
		gbc_panel_5.insets = new Insets(0, 0, 5, 5);
		gbc_panel_5.fill = GridBagConstraints.VERTICAL;
		gbc_panel_5.gridx = 8;
		gbc_panel_5.gridy = 3;
		panel.add(panel_5, gbc_panel_5);
		
		
		
		
		flujoRespiratorio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(flujoRespiratorio.isSelected()) {
					Temp_FIR_LP_2H.setSelected(true);
					Temp_FIR_LP_7H.setSelected(true);
					Temp_FIR_LP_8H.setSelected(true);
					Pletismografo.setSelected(true);
					Temp.setSelected(true);
					Suma_RIP.setSelected(true);
					Flujo_RIP.setSelected(true);
					Fase_RIP.setSelected(true);
				}else {
					Temp_FIR_LP_2H.setSelected(false);
					Temp_FIR_LP_7H.setSelected(false);
					Temp_FIR_LP_8H.setSelected(false);
					Pletismografo.setSelected(false);
					Temp.setSelected(false);
					Suma_RIP.setSelected(false);
					Flujo_RIP.setSelected(false);
					Fase_RIP.setSelected(false);
				}
			}
		});
		
		esfuerzoRespiratorio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(esfuerzoRespiratorio.isSelected()) {
					Abdomen.setSelected(true);
					Frecuencia_Respiratoria.setSelected(true);
					Pulso.setSelected(true);
					Torax.setSelected(true);
					Presion_de_mascara.setSelected(true);
				}else {
					Abdomen.setSelected(false);
					Frecuencia_Respiratoria.setSelected(false);
					Pulso.setSelected(false);
					Torax.setSelected(false);
					Presion_de_mascara.setSelected(false);
				}
			}
		});
		
		
		PosicionMovimiento.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(PosicionMovimiento.isSelected()) {
					EjeX.setSelected(true);
					EjeY.setSelected(true);
					EjeZ.setSelected(true);
					Posicion.setSelected(true);
					Elevacion.setSelected(true);
					Actividad.setSelected(true);
				}else {
					EjeX.setSelected(false);
					EjeY.setSelected(false);
					EjeZ.setSelected(false);
					Posicion.setSelected(false);
					Elevacion.setSelected(false);
					Actividad.setSelected(false);
				}
			}
		});
		
		DesaturacionOxigeno.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(DesaturacionOxigeno.isSelected()) {
					SpO2.setSelected(true);
					SpO2BB.setSelected(true);
				}else {
					SpO2.setSelected(false);
					SpO2BB.setSelected(false);
				}
			}
		});
		
		
		SonidoBig.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(SonidoBig.isSelected()) {
					Audio.setSelected(true);
					Sonido.setSelected(true);
				}else {
					Audio.setSelected(false);
					Sonido.setSelected(false);
				}
			}
		});
		//Submit
		
		JButton Plot = new JButton("Plot");
		GridBagConstraints gbc_Plot = new GridBagConstraints();
		gbc_Plot.insets = new Insets(0, 0, 0, 5);
		gbc_Plot.gridx = 5;
		gbc_Plot.gridy = 12;
		panel.add(Plot, gbc_Plot);
		
		Plot.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				selectedParameters = validatePanel(panel);
				if (selectedParameters.size()>0){
					//System.out.println("ploted");
					System.out.println(selectedParameters);
					itxiLeihoa();
				}else {
					System.out.println("Not selected");
				}
				
				/*
				if(selectedParameters.size() > 0) {
					for(String param : selectedParameters) {
						ImageViewPopUp plotImages = new ImageViewPopUp(param);
						plotImages.main(param);
					}
					
					
					
					
					
			    }else {
			    	System.out.println("Not selected"); //TODO Default ++ popup
			    	
			    }
			    */
			}

			
		});
	}
	private void itxiLeihoa() {
		// TODO Auto-generated method stub
		this.setVisible(false);
	}
	private ArrayList<String> validatePanel(JPanel panel) {   
		ArrayList<String> selectedParameters = new ArrayList<String>();
		
	    for (Component component : panel.getComponents()) {
	        if(component instanceof JCheckBox){
	            JCheckBox c = (JCheckBox) component;
	            if(c.isSelected()){
	            	//String selectedParameter = normalizeText(c.getText());
	            	selectedParameters.add(c.getText());
	            }
	        }
	    }
	    return selectedParameters;
	    
		
	   
	}
	/*
	public String normalizeText(String label) {
		// TODO Auto-generated method stub
		switch (label) {
		case "Abdomen         ":
			label = "Abdomen";
			break;
		case "Actividad       ":
			label = "Actividad";
			break;
		case "Eje X           ":
			label = "EjeX";
			break;
		case "Eje Y           ":
			label = "EjeY";
			break;
		case "Eje Z           ":
			label = "EjeZ";
			break;
		case "Elevacin      ":
			label = "Elevacin";
			break;
		case "Elevaci?n       ":
			label = "Elevacin";
			break;
		case "Fase RIP        ":
			label = "FaseRIP";
			break;
		case "Flujo RIP       ":
			label = "FlujoRIP";
			break;
		case "Frec. Resp.     ":
			label = "FrecResp";
			break;
		case "Pletismgrafo  ":
			label = "Pletismgrafo";
			break;
		case "Pletism?grafo   ":
			label = "Pletismgrafo";
			break;
		case "Posici?n        ":
			label = "Posicin";
			break;
		case "Posicin       ":
			label = "Posicin";
			break;
		case "Pulso           ":
			label = "Pulso";
			break;
		case "Presi?n de m?sca":
			label = "Presin de msca";
			break;
		case "SpO2            ":
			label = "SpO2";
			break;
		case "SpO2 B-B        ":
			label = "SpO2BB";
			break;
		case "Suma RIP        ":
			label = "SumaRIP";
			break;
		case "Temp            ":
			label = "Temp";
			break;
		case "Temp [FIR-LP: 8H":
			label = "TempFIRLP8H";
			break;
		case "Trax          ":
			label = "Torax";
			break;
		case "T?rax           ":
			label = "Torax";
			break;
		case "Volumen de Audio":
			label = "VolDeAudio";
			break;
		case "Volumen de sonid":
			label = "VolDeSonido";
			break;
		}

		return label;
		
	}
	*/
	public ArrayList<String> getParameters(){
		int index = 0;
		while(selectedParameters == null) {
			//System.out.println("index: "+index++);
		}
		//System.out.println("Returning parameters");
		//System.out.println(selectedParameters);
		return selectedParameters;
		
	}
}

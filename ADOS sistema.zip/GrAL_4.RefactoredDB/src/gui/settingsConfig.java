package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import javax.swing.JTextField;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class settingsConfig extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField ThresholdField;
	private JTextField IntervalField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			settingsConfig dialog = new settingsConfig();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public settingsConfig() {
		setTitle("Plot With Highlights Settings");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		GridBagLayout gbl_contentPanel = new GridBagLayout();
		gbl_contentPanel.columnWidths = new int[] { 0, 0, 36, 0, 0 };
		gbl_contentPanel.rowHeights = new int[] { 0, 0, 0, 13, 0, 0, 0 };
		gbl_contentPanel.columnWeights = new double[] { 1.0, 0.0, 0.0, 1.0, Double.MIN_VALUE };
		gbl_contentPanel.rowWeights = new double[] { 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE };
		contentPanel.setLayout(gbl_contentPanel);
		{
			JLabel ThresholdLabel = new JLabel("Highlight Threshold");
			GridBagConstraints gbc_ThresholdLabel = new GridBagConstraints();
			gbc_ThresholdLabel.insets = new Insets(0, 0, 5, 5);
			gbc_ThresholdLabel.gridx = 1;
			gbc_ThresholdLabel.gridy = 1;
			contentPanel.add(ThresholdLabel, gbc_ThresholdLabel);
		}
		{
			ThresholdField = new JTextField();
			GridBagConstraints gbc_ThresholdField = new GridBagConstraints();
			gbc_ThresholdField.insets = new Insets(0, 0, 5, 5);
			gbc_ThresholdField.gridx = 2;
			gbc_ThresholdField.gridy = 1;
			contentPanel.add(ThresholdField, gbc_ThresholdField);
			ThresholdField.setColumns(10);
		}
		{
			JLabel ThresholdIntervalLabel = new JLabel("Threshold Interval");
			GridBagConstraints gbc_ThresholdIntervalLabel = new GridBagConstraints();
			gbc_ThresholdIntervalLabel.anchor = GridBagConstraints.EAST;
			gbc_ThresholdIntervalLabel.insets = new Insets(0, 0, 5, 5);
			gbc_ThresholdIntervalLabel.gridx = 1;
			gbc_ThresholdIntervalLabel.gridy = 2;
			contentPanel.add(ThresholdIntervalLabel, gbc_ThresholdIntervalLabel);
		}
		{
			IntervalField = new JTextField();
			IntervalField.setColumns(10);
			GridBagConstraints gbc_IntervalField = new GridBagConstraints();
			gbc_IntervalField.insets = new Insets(0, 0, 5, 5);
			gbc_IntervalField.gridx = 2;
			gbc_IntervalField.gridy = 2;
			contentPanel.add(IntervalField, gbc_IntervalField);
		}
		{
			JButton Submit = new JButton("Ok");
			Submit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

				}
			});
			GridBagConstraints gbc_Submit = new GridBagConstraints();
			gbc_Submit.insets = new Insets(0, 0, 5, 5);
			gbc_Submit.gridx = 1;
			gbc_Submit.gridy = 4;
			contentPanel.add(Submit, gbc_Submit);
		}
	}

}

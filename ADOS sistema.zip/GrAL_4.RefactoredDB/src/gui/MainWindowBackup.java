package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.JMenu;
import java.awt.GridBagConstraints;
import javax.swing.JMenuBar;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Insets;
import javax.swing.SwingConstants;
import javax.swing.JMenuItem;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JTextPane;
public class MainWindowBackup extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindowBackup frame = new MainWindowBackup();
					frame.setVisible(true);
					frame.setTitle("ADS");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainWindowBackup() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel MenuPanel = new JPanel();
		contentPane.add(MenuPanel, BorderLayout.NORTH);
		GridBagLayout gbl_MenuPanel = new GridBagLayout();
		gbl_MenuPanel.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_MenuPanel.rowHeights = new int[]{0, 0};
		gbl_MenuPanel.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_MenuPanel.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		MenuPanel.setLayout(gbl_MenuPanel);
		
		JMenuBar menuBar = new JMenuBar();
		GridBagConstraints gbc_menuBar = new GridBagConstraints();
		gbc_menuBar.insets = new Insets(0, 0, 0, 5);
		gbc_menuBar.gridx = 0;
		gbc_menuBar.gridy = 0;
		MenuPanel.add(menuBar, gbc_menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_1 = new JMenu("Load Study");
		mnNewMenu.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Load from edf");
		mnNewMenu_1.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Load from database");
		mnNewMenu_1.add(mntmNewMenuItem_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Preview Raw Data");
		mnNewMenu.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Simplify Data");
		mnNewMenu.add(mntmNewMenuItem_3);
		
		JMenu mnNewMenu_4 = new JMenu("Plot Data");
		mnNewMenu.add(mnNewMenu_4);
		
		JMenuItem plotRaw = new JMenuItem("Plot Raw");
		
		
		mnNewMenu_4.add(plotRaw);
		
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("Plot Highlights");
		mnNewMenu_4.add(mntmNewMenuItem_5);
		
		JMenuItem mntmNewMenuItem_6 = new JMenuItem("Plot With Events");
		mnNewMenu_4.add(mntmNewMenuItem_6);
		
		JMenuItem mntmNewMenuItem_7 = new JMenuItem("Create Summary");
		mnNewMenu.add(mntmNewMenuItem_7);
		
		JMenu mnNewMenu_6 = new JMenu("Settings");
		menuBar.add(mnNewMenu_6);
		
		JMenuItem mntmNewMenuItem_8 = new JMenuItem("Set database");
		mnNewMenu_6.add(mntmNewMenuItem_8);
		
		JMenuItem mntmNewMenuItem_9 = new JMenuItem("Statistical Settings");
		mnNewMenu_6.add(mntmNewMenuItem_9);
		
		JMenu mnNewMenu_2 = new JMenu("More...");
		mnNewMenu_6.add(mnNewMenu_2);
		
		JButton btnNewButton = new JButton("Log Out");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				itxiMain();
			}
		});
		
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridx = 9;
		gbc_btnNewButton.gridy = 0;
		MenuPanel.add(btnNewButton, gbc_btnNewButton);
		
		JPanel Central_Panel = new JPanel();
		contentPane.add(Central_Panel, BorderLayout.CENTER);
		GridBagLayout gbl_Central_Panel = new GridBagLayout();
		gbl_Central_Panel.columnWidths = new int[]{0, 0};
		gbl_Central_Panel.rowHeights = new int[]{211, 53, 0};
		gbl_Central_Panel.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_Central_Panel.rowWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		Central_Panel.setLayout(gbl_Central_Panel);
		
		JScrollPane previewBox = new JScrollPane();
		GridBagConstraints gbc_previewBox = new GridBagConstraints();
		gbc_previewBox.insets = new Insets(0, 0, 5, 0);
		gbc_previewBox.fill = GridBagConstraints.BOTH;
		gbc_previewBox.gridx = 0;
		gbc_previewBox.gridy = 0;
		Central_Panel.add(previewBox, gbc_previewBox);
		
		JLabel lblNewLabel = new JLabel("Preview Box");
		previewBox.setColumnHeaderView(lblNewLabel);
		
		JPanel PreviewPort = new JPanel();
		previewBox.setViewportView(PreviewPort);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		GridBagConstraints gbc_scrollPane_1 = new GridBagConstraints();
		gbc_scrollPane_1.fill = GridBagConstraints.BOTH;
		gbc_scrollPane_1.gridx = 0;
		gbc_scrollPane_1.gridy = 1;
		Central_Panel.add(scrollPane_1, gbc_scrollPane_1);
		
		JLabel lblNewLabel_1 = new JLabel("Feedback Box");
		scrollPane_1.setColumnHeaderView(lblNewLabel_1);
		
		JTextPane feedbackPane = new JTextPane();
		scrollPane_1.setViewportView(feedbackPane);
		
		plotRaw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("action performed");
				
				ImageIcon img = new ImageIcon();
				BufferedImage wPic = null;
				try {
					wPic = ImageIO.read(this.getClass().getResource("05-12-16_Abdomen.png"));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JLabel wIcon = new JLabel(new ImageIcon(wPic));
				PreviewPort.add(wIcon);
				PreviewPort.setBackground(new Color(0, 0, 0));
				PreviewPort.setForeground(new Color(0, 0, 0));
				PreviewPort.setVisible(false);
				PreviewPort.setVisible(true);
				PreviewPort.repaint();
				
				
				
				feedbackPane.setText(feedbackPane.getText()+"\n Data Previewed");
				/*
				JPanel pRPanel = new JPanel();
				
				ImageIcon img = new ImageIcon();
				BufferedImage wPic = null;
				try {
					wPic = ImageIO.read(this.getClass().getResource("05-12-16_Abdomen.png"));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JLabel wIcon = new JLabel(new ImageIcon(wPic));
				pRPanel.add(wIcon);
				
				plotRaw.add(pRPanel);
				plotRaw.add(new JLabel("EYYYYY"));
				JPanel JPanel = new JPanel( new GridLayout(0, 6) );
				JPanel.setBackground(new Color(0, 0,0));
				plotRaw.add(JPanel);
				*/
				/*
				ImageIcon img = new ImageIcon();
				
				BufferedImage wPic = null;
				try {
					wPic = ImageIO.read(this.getClass().getResource("05-12-16_Abdomen.png"));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JLabel wIcon = new JLabel(new ImageIcon(wPic));
				plotRaw.add(wIcon);
				plotRaw.add(new ImageIcon(wPic));
				//add(picLabel);
				*/
				/*
				JPanel pBoxpanel = new JPanel();
				pBoxpanel.add(img);
				previewBox.add(pBoxpanel);
				//lekua4.setIcon(new ImageIcon(oldBARBESTIAL.class.getResource(Partida.getPartida().getTablerokoKartaIzena(4)+Partida.getPartida().getTablerokoKartaKol(4)+".png").getFile()));
				
				*/
			}
		});
		
	}

	// TODO Auto-generated method stub
	private void itxiMain() {
		// TODO Auto-generated method stub
		System.out.println("Closing window");
		this.dispose();
		System.out.println("Opening login");
		LoginWindow lW = new LoginWindow();
		lW.main(null);
	}


}

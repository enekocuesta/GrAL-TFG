package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.imageio.ImageIO;
public class ImageViewPopUp extends JFrame {

	private JPanel contentPane;	
	
	/**
	 * Launch the application.
	 */
	public static void main(String param) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ImageViewPopUp frame = new ImageViewPopUp(param);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param param 
	 */
	public ImageViewPopUp(String param) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel previewPort = new JPanel();
		contentPane.add(previewPort, BorderLayout.CENTER);
		
		
		
		
		
		
		
		
		
		try{
			//System.out.println(previewPort.getComponentCount());
			//System.out.println(previewPort.getComponent(0));
			//checkear si el child tiene mas components
			//previewPort.getComponent(0).remove(previewPort.getComponent(0).getComponent(0));
			previewPort.remove(previewPort.getComponent(0));
			previewPort.repaint();
		}catch(Exception e1) {
			System.out.println("Not img yet");
		}
		
		//System.out.println("action performed");
		
		ImageIcon img = new ImageIcon();
		BufferedImage wPic = null;
		Image newImage = null;
		try {
			File folder = new File("C:\\Users\\Eneko Cuesta\\Desktop\\KLASE\\GraL\\Gnuplot\\output");
			File[] listOfFiles = folder.listFiles();
			//System.out.println(param);

			for (File f : listOfFiles) {
				try {
				//System.out.println(f.getName().split("_")[1]);
				if (f.getName().split("_")[1].equals(param + ".png")) {
					wPic = ImageIO.read(f);

					//System.out.println(f.getName());
					newImage = wPic.getScaledInstance(1920, 1080, Image.SCALE_SMOOTH);
					JLabel wIcon = new JLabel(new ImageIcon(newImage));

					previewPort.add(wIcon);
					previewPort.setBackground(new Color(0, 0, 0));
					previewPort.setForeground(new Color(0, 0, 0));
					previewPort.setVisible(false);
					previewPort.setVisible(true);
					previewPort.repaint();
					
					
					//System.out.println("Data Previewed");
				}
				}catch(java.lang.IllegalArgumentException | java.lang.ArrayIndexOutOfBoundsException e) {
					//System.out.println(f.getName());
					e.printStackTrace();
				}
				// TODO a�adir el size que quieras
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
	}

}

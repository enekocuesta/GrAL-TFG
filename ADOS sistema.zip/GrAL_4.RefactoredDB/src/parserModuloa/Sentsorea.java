package parserModuloa;

import datuBasea.DbGalderak;

public class Sentsorea {
	
	private int kodea;
	private String izena;
	private String azalpena;
	private String unitateak;
	private int balioMin;
	private int balioMax;
	private String mota;
	
	public Sentsorea(int pKodea, String pIzena, String pAzalpena, String pUn, int pbalioMin, int pbalioMax, String pMota) {
		kodea = pKodea;
		izena = pIzena;
		azalpena = pAzalpena;
		unitateak = pUn;
		balioMin = pbalioMin;
		balioMax = pbalioMax;
		mota = pMota;
		
		if(!sentsoreaExists()) {
			DbGalderak.sendUpdate("Insert into Sentsorea(kodea,izena,min,max,sMota) values("+
					kodea+","+
					"'"+izena+"'"+","+
					balioMin+","+
					balioMax+","+
					"'"+mota+"'"+
					")");
		}
		
	}
	
	private boolean sentsoreaExists() {
		if(DbGalderak.sendWithReturnArray("Select * from Sentsorea where kodea = '"+kodea+"'").size()>0) {
			return true;
		}else {
			return false;
		}
	}













	public int getKodea() {
		return kodea;
	}

	public void setKodea(int kodea) {
		this.kodea = kodea;
	}

	public String getIzena() {
		return izena;
	}

	public void setIzena(String izena) {
		this.izena = izena;
	}

	public String getAzalpena() {
		return azalpena;
	}

	public void setAzalpena(String azalpena) {
		this.azalpena = azalpena;
	}

	public String getUnitateak() {
		return unitateak;
	}

	public void setUnitateak(String unitateak) {
		this.unitateak = unitateak;
	}

	public int getBalioMin() {
		return balioMin;
	}

	public void setBalioMin(int balioMin) {
		this.balioMin = balioMin;
	}

	public int getBalioMax() {
		return balioMax;
	}

	public void setBalioMax(int balioMax) {
		this.balioMax = balioMax;
	}

	
}

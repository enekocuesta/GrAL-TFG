package parserModuloa;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Stream;

import javax.swing.JFileChooser;

import datuBasea.DbGalderak;
import datuBasea.DbKonexioa;
import edfParserUtils.EDFParser;
import edfParserUtils.EDFParserResult;
import gui.MainWindow;

import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import com.panayotis.gnuplot.JavaPlot;
import com.panayotis.gnuplot.plot.AbstractPlot;
import com.panayotis.gnuplot.style.NamedPlotColor;
import com.panayotis.gnuplot.style.PlotStyle;
import com.panayotis.gnuplot.style.Style;
public class Main {
	// Directorios (en un futuro se eligen con file explorer)
	private static String workingDirectory = "";
	private File edfFile;
	private PatientList patientList;
	// settings
	private static int threshold;

	private static int intervalSecs;

	public Main() {
		patientList = new PatientList();

		// Cargar settings
		createSettingFile();
		loadSettings();

		// database
		insertConstants();

	}

	private void insertConstants() {
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) {
		MainWindow m = new MainWindow();
		m.setVisible(true);
	}

	private static String getPatientId(File edfFile) {
		/*
		 * EDFParserResult result = null; File f = new File(fullEDFPath); InputStream is
		 * = null;
		 * 
		 * // ERRORE TRATAERA AZKARRA try { is = new FileInputStream(f); result =
		 * EDFParser.parseEDF(is); } catch (FileNotFoundException e) { // TODO
		 * Auto-generated catch block e.printStackTrace();
		 * System.out.println("PeriodListCreator.createPeriodList():: error fichero " +
		 * fullEDFPath); } catch (IOException e) { // TODO Auto-generated catch block
		 * e.printStackTrace();
		 * System.out.println("PeriodListCreator.createPeriodList():: error fichero " +
		 * fullEDFPath); } finally { try { is.close(); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } }
		 */
		// izena anonimoa izan behar da //
		// result.getHeader().getSubjectID().substring(0, 19);
		return edfFile.getName().split(".edf")[0].strip();
	}

	public static String getWorkingDirectory() {
		return workingDirectory;
	}

	private static void setOutputDirectory(File file) {
		File dir = new File(file.getParent() + "\\plots");
	    if (!dir.exists()) dir.mkdirs();
		workingDirectory = file.getParent() + "\\plots";
		System.out.println("Output Directory: " + workingDirectory);
	}

	private void loadFile() {
		// TODO Auto-generated method stub
		JFileChooser f = new JFileChooser();
		f.setDialogTitle("Selecciona el fichero EDF");
		f.setFileSelectionMode(JFileChooser.FILES_ONLY);
		f.showSaveDialog(null);
		// C:\Users\Eneko Cuesta\Desktop\KLASE\GraL\Input\800648.edf
		setEDFFile(f.getSelectedFile());
		setOutputDirectory(f.getSelectedFile());
		System.out.println("Selected File: " + getEdfFile().toString());
	}

	public void loadEDF() {
		// TODO Auto-generated method stub
		// Load File
		loadFile();
		// Create patient
		Patient patient = new Patient(getEdfFile());
		// add studio
		System.out.println("adding Study");
		patient.addEstudio(getEdfFile().toString());
		patientList.add(patient);

		// Only check if exists in database when you choose to save to database
	}

	private File getEdfFile() {
		// TODO Auto-generated method stub
		return edfFile;
	}

	private void setEDFFile(File file) {
		// TODO Auto-generated method stub
		edfFile = file;
	}

	public Study previewRawData() {
		// TODO Auto-generated method stub
		return patientList.previewRawData(this.getPatientId(edfFile));
	}

	public String getPatientName() {
		// TODO Auto-generated method stub
		return getPatientId(edfFile);
	}

	public void plotByParams(ArrayList<String> params, boolean highlights) {
		patientList.plotByParams(this.getPatientId(edfFile), params, highlights);
	}

	public void replot(ArrayList<String> selectedParameters, String from, String to, boolean highlights) {
		// TODO Auto-generated method stub
		patientList.rePlotByParams(this.getPatientId(edfFile), selectedParameters, from, to, highlights);
	}

	/*
	 * public void plotByParamsHighlights(ArrayList<String> selectedParameters) { //
	 * TODO Auto-generated method stub
	 * patientList.plotByParamsHighlights(this.getPatientId(edfFile),
	 * selectedParameters); }
	 * 
	 * public void replotPicos(ArrayList<String> selectedParameters, String from,
	 * String to) { // TODO Auto-generated method stub
	 * patientList.rePlotByPicos(this.getPatientId(edfFile), selectedParameters,
	 * from, to); }
	 */
	public void createSettingFile() {
		try {
			File settings = new File(System.getProperty("user.dir"), "settings.txt");
			if (settings.createNewFile()) {
				System.out.println("File created: " + settings.getName());
				FileWriter myWriter = new FileWriter("./config/settings.txt");
				myWriter.write("Highlight threshold: 25\n");
				myWriter.write("Highlight interval: 60\n");
				myWriter.close();
			} else {
				System.out.println("File already exists.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void loadSettings() {
		try {
			// createSettingFile(); //Checkea por si se ha borrado
			System.out.println(System.getProperty("user.dir")+"\\"+"settings.txt");

			FileReader reader = new FileReader(System.getProperty("user.dir")+"\\"+"settings.txt");
			
			
			
			BufferedReader bufferedReader = new BufferedReader(reader);

			String line;

			while ((line = bufferedReader.readLine()) != null) {
				System.out.println(line);
				if (line.split(": ")[0].equals("Highlight threshold")) {
					threshold = Integer.parseInt(line.split(": ")[1]);
				} else if (line.split(": ")[0].equals("Highlight interval")) {
					intervalSecs = Integer.parseInt(line.split(": ")[1]);
				}
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void setSetting(String stringLine, String value) {
		// TODO Auto-generated method stub
		try {
			// createSettingFile(); //Checkea por si se ha borrado

			FileReader reader = new FileReader("./config/settings.txt");
			BufferedReader bufferedReader = new BufferedReader(reader);

			String line;

			while ((line = bufferedReader.readLine()) != null) {
				//
				// Instantiating the File class
				String filePath = "./config/settings.txt";
				// Instantiating the Scanner class to read the file
				Scanner sc = new Scanner(new File(filePath));
				// instantiating the StringBuffer class
				StringBuffer buffer = new StringBuffer();
				// Reading lines of the file and appending them to StringBuffer
				while (sc.hasNextLine()) {
					buffer.append(sc.nextLine() + System.lineSeparator());
				}
				String fileContents = buffer.toString();
				// System.out.println("Contents of the file: \n" + fileContents);
				// closing the Scanner object
				sc.close();
				String oldLine = "";
				if (line.split(": ")[0].equals(stringLine)) {
					line.split(": ")[1] = value;
					oldLine = line.split(": ")[1];
					String newLine = value;
					// Replacing the old line with new line
					fileContents = fileContents.replaceAll(oldLine, newLine);
					// instantiating the FileWriter class
					FileWriter writer = new FileWriter(filePath);
					// System.out.println("");
					// System.out.println("new data: " + fileContents);
					writer.append(fileContents);
					writer.flush();
				} else if (line.split(": ")[0].equals(stringLine)) {
					line.split(": ")[1] = value;
					oldLine = line.split(": ")[1];
					String newLine = value;
					// Replacing the old line with new line
					fileContents = fileContents.replaceAll(oldLine, newLine);
					// instantiating the FileWriter class
					FileWriter writer = new FileWriter(filePath);
					// System.out.println("");
					// System.out.println("new data: " + fileContents);
					writer.append(fileContents);
					writer.flush();
				}

				//
			}
			reader.close();
			loadSettings();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static int getIntervalSecs() {
		return intervalSecs;
	}

	public static int getThreshold() {
		return threshold;
	}

	public void uploadPicos(ArrayList<String> selectedParameters) {
		patientList.uploadPicos(this.getPatientId(edfFile), selectedParameters);

	}

	public void uploadEvents() {
		patientList.uploadEvents(this.getPatientId(edfFile));
	}

	public void createSummary() {
		// TODO Auto-generated method stub
		// document.save("C:/users/eneko cuesta/desktop/test.pdf");
		// C:/Users/Eneko Cuesta/Desktop/Klase/Gral/Memoria/testimage.jpg
		
		float fontSize = 12;
		float fontHeight = fontSize;
		float leading = 20;

		String Identifikatzailea = getEdfFile().getName().split(".edf")[0];
		String HasieraData = DbGalderak.sendWithReturnArray("SELECT hasiera from proba where gaKodea = '" + Identifikatzailea+"'").get(0).get(0).split(" ")[0];
		String hasieraOrdua = DbGalderak.sendWithReturnArray("SELECT hasiera from proba where gaKodea = '" + Identifikatzailea+"'").get(0).get(0).split(" ")[1];
		String BukaeraData = DbGalderak.sendWithReturnArray("SELECT bukaera from proba where gaKodea = '" + Identifikatzailea+"'").get(0).get(0).split(" ")[0];
		String BukaeraOrdua = DbGalderak.sendWithReturnArray("SELECT bukaera from proba where gaKodea = '" + Identifikatzailea+"'").get(0).get(0).split(" ")[1];
		String HpnaTotala = DbGalderak.sendWithReturnArray("SELECT COUNT( DISTINCT denboraMarka) from datuak where gaKodea = '"+Identifikatzailea+"' and gertaera is not null").get(0).get(0);
		//String hpnaLuze = "";
		String btbPults = DbGalderak.sendWithReturnArray("select avg(datua) from datuak where gaKodea = '"+Identifikatzailea+"' and sKodea = 11").get(0).get(0);
		String pultsMax = DbGalderak.sendWithReturnArray("select MAX(datua) from datuak where gaKodea = "+Identifikatzailea+" and sKodea = 11").get(0).get(0);
		String pultsMin = DbGalderak.sendWithReturnArray("select MIN(datua) from datuak where gaKodea = "+Identifikatzailea+" and sKodea = 11").get(0).get(0);
		int hpna[] = sortuIrudia(HasieraData,hasieraOrdua,Identifikatzailea);
		System.out.println("data: "+HasieraData);
		System.out.println("data: "+BukaeraData);
		System.out.println("ident: "+Identifikatzailea);
		System.out.println("data: "+hasieraOrdua);
		System.out.println("ident: "+BukaeraOrdua);
		System.out.println("ident: "+HpnaTotala);
		System.out.println("ident: "+btbPults);
		System.out.println("data: "+pultsMax);
		System.out.println("ident: "+pultsMin);

		try (PDDocument doc = new PDDocument()) {

			PDPage myPage2 = new PDPage();
			doc.addPage(myPage2);

			try (PDPageContentStream cont = new PDPageContentStream(doc, myPage2)) {
				float yCordinate = myPage2.getCropBox().getUpperRightY() - 30;
				float startX = myPage2.getCropBox().getLowerLeftX() + 30;
				float endX = myPage2.getCropBox().getUpperRightX() - 30;


				cont.beginText();

				cont.setFont(PDType1Font.TIMES_BOLD, 24);
				cont.setLeading(14.5f);
				//width height
				cont.newLineAtOffset(175, 750);
				String line1 = "Arnasketaren informea";
				cont.showText(line1);

				cont.setFont(PDType1Font.TIMES_ROMAN, fontSize);
				//
				cont.endText();

				cont.beginText();
				yCordinate -=70;
				cont.setFont(PDType1Font.TIMES_BOLD, fontSize);
				cont.newLineAtOffset(startX, yCordinate);
				cont.showText("Gaixoaren informazioa");
				cont.setFont(PDType1Font.TIMES_ROMAN, fontSize);
				yCordinate -= fontHeight;  //This line is to track the yCordinate
				cont.newLineAtOffset(16, -leading);
				yCordinate -= leading;
				cont.showText("Identifikatzaile anonimoa: " + Identifikatzailea);
				cont.endText(); // End of text mode

				cont.moveTo(startX, yCordinate);
				cont.lineTo(endX, yCordinate);
				cont.stroke();
				yCordinate -= leading;

				cont.beginText();
				cont.newLineAtOffset(startX, yCordinate);
				cont.setFont(PDType1Font.TIMES_BOLD, fontSize);
				cont.showText("Erregistro informazioa ");
				cont.setFont(PDType1Font.TIMES_ROMAN, fontSize);
				yCordinate -= fontHeight;  //This line is to track the yCordinate
				cont.newLineAtOffset(16, -leading);
				yCordinate -= leading;
				cont.showText("Hasiera data: "+HasieraData);
				yCordinate -= fontHeight;
				cont.newLineAtOffset(0, -leading);
				yCordinate -= leading;
				cont.showText("Hasiera ordua: "+hasieraOrdua);
				yCordinate -= fontHeight;
				cont.newLineAtOffset(0, -leading);
				yCordinate -= leading;
				cont.showText("Bukaera data: "+BukaeraData);
				yCordinate -= fontHeight;
				cont.newLineAtOffset(0, -leading);
				yCordinate -= leading;
				cont.showText("Bukaera ordua: "+BukaeraOrdua);
				cont.endText();

				cont.moveTo(startX, yCordinate);
				cont.lineTo(endX, yCordinate);
				cont.stroke();
				yCordinate -= leading;

				cont.beginText();
				cont.newLineAtOffset(startX, yCordinate);
				cont.setFont(PDType1Font.TIMES_BOLD, fontSize);
				cont.showText("Ikuspegi orokorra");
				cont.setFont(PDType1Font.TIMES_ROMAN, fontSize);
				yCordinate -= fontHeight;  //This line is to track the yCordinate
				cont.newLineAtOffset(16, -leading);
				yCordinate -= leading;
				cont.showText("Hipoapnea kopurua: "+hpna[1]);
				yCordinate -= fontHeight;
				cont.newLineAtOffset(0, -leading);
				yCordinate -= leading;
				cont.showText("Hipoapnea luzeena: " + hpna[0]+ " segundu");
				cont.endText();

				cont.moveTo(startX, yCordinate);
				cont.lineTo(endX, yCordinate);
				cont.stroke();
				yCordinate -= leading;
				
				
				
				cont.beginText();
				cont.newLineAtOffset(startX, yCordinate);
				cont.setFont(PDType1Font.TIMES_BOLD, fontSize);
				cont.showText("Pultsu indizeak");
				cont.setFont(PDType1Font.TIMES_ROMAN, fontSize);
				yCordinate -= fontHeight;  //This line is to track the yCordinate
				cont.newLineAtOffset(16, -leading);
				yCordinate -= leading;
				cont.showText("Bataz besteko pultsua: "+btbPults);
				yCordinate -= fontHeight;  //This line is to track the yCordinate
				cont.newLineAtOffset(0, -leading);
				yCordinate -= leading;
				cont.showText("Pultsurik altuena: "+pultsMax);
				yCordinate -= fontHeight;  //This line is to track the yCordinate
				cont.newLineAtOffset(0, -leading);
				yCordinate -= leading;
				cont.showText("Pultsurik baxuena: "+pultsMin);
				cont.endText();
				
				cont.moveTo(startX, yCordinate);
				cont.lineTo(endX, yCordinate);
				cont.stroke();
				yCordinate -= leading;
				
				String imgFileName = "C:/Users/Eneko Cuesta/Desktop/Klase/Gral/Input/plots/"+Identifikatzailea+"-gertaerak.png";
				PDImageXObject pdImage = PDImageXObject.createFromFile(imgFileName, doc);
				cont.drawImage(pdImage, 0, 550-(240*2), 625, 225);
				cont.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			//////

			System.out.println("C:/Users/Eneko Cuesta/Desktop/Klase/Gral/Input/plots/"+Identifikatzailea+"-"+HasieraData+"-"+hasieraOrdua.replaceAll(":", "-")+"__Pulso.png");

			PDPage myPage = new PDPage();
			doc.addPage(myPage);
			String imgFileName = "C:/Users/Eneko Cuesta/Desktop/Klase/Gral/Input/plots/"+Identifikatzailea+"-gertaerak.png";
			PDImageXObject pdImage = PDImageXObject.createFromFile(imgFileName, doc);
			String imgFileName2 = "C:/Users/Eneko Cuesta/Desktop/Klase/Gral/Input/plots/"+Identifikatzailea+"-"+HasieraData+"-"+hasieraOrdua.replaceAll(":", "-")+"__Pulso.png";
			PDImageXObject pdImage2 = PDImageXObject.createFromFile(imgFileName2, doc);
			String imgFileName3 = "C:/Users/Eneko Cuesta/Desktop/Klase/Gral/Input/plots/"+Identifikatzailea+"-"+HasieraData+"-"+hasieraOrdua.replaceAll(":", "-")+"__Suma-RIP.png";
			PDImageXObject pdImage3 = PDImageXObject.createFromFile(imgFileName3, doc);
			String imgFileName4 = "C:/Users/Eneko Cuesta/Desktop/Klase/Gral/Input/plots/"+Identifikatzailea+"-"+HasieraData+"-"+hasieraOrdua.replaceAll(":", "-")+"__Temp.png";
			PDImageXObject pdImage4 = PDImageXObject.createFromFile(imgFileName4, doc);
			
			try (PDPageContentStream cont = new PDPageContentStream(doc, myPage)) {
				//cont.drawImage(pdImage, 0, 550, 625, 225);
				cont.drawImage(pdImage2, 0, 550, 625, 225);
				cont.drawImage(pdImage3, 0, 550-240, 625, 225);
				cont.drawImage(pdImage4, 0, 550-(240*2), 625, 225);
			}
			doc.save("C:/users/eneko cuesta/desktop/test.pdf");


		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

	private int[] sortuIrudia(String hasieraData, String hasieraOrdua, String identifikatzailea) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		// System.out.println("Plotting by Params: " + params);
		int seinaleKodea = 0;
		int scalerMax;
		int scalerMin;
		ArrayList<ArrayList<String>> resultRows = DbGalderak.sendWithReturnArray("select denboraMarka from datuak where gaKodea = '"+identifikatzailea+"' and gertaera is not null and pData='"+hasieraData+" "+hasieraOrdua+ "' order by 1");
		String denboraBukaera = DbGalderak.sendWithReturnArray("select max(denboraMarka) from datuak where gaKodea = '"+identifikatzailea+"' and pData='"+hasieraData+" "+hasieraOrdua+ "'").get(0).get(0);
		int bukaera = Integer.parseInt(denboraBukaera);
		int[][] fPlot = new int[bukaera + 1][1];
		ArrayList<String> segunduak = new ArrayList<String>();
		int hpnaLuzeKont = 0;
		int maxhpna = 0;
		int hpnaKop=-1;
		int previous = -2;
		for(ArrayList<String> r : resultRows) {
			segunduak.add(r.get(0));
			if(previous+1==Integer.parseInt(r.get(0))) {
				hpnaLuzeKont++;
			}else {
				if(hpnaLuzeKont>maxhpna) {
					maxhpna = hpnaLuzeKont;
				}
				hpnaLuzeKont = 0;
				hpnaKop++;
			}
			previous = Integer.parseInt(r.get(0));
		}
		
		int kont = 0;
		for(int s = 1; s <=bukaera; s++) {
			//System.out.println(segunduak.get(s));
			if(segunduak.get(kont).equals(Integer.toString(s))) {
				fPlot[s][0] = 20;
				kont++;
			}else {
				fPlot[s][0] = 0;
			}
		}


		JavaPlot p = new JavaPlot();
		p.setTitle("Hipoapneak");

		// DATA
		p.addPlot(fPlot);
		p.getAxis("x").setLabel("Denbora (s)");
		p.getAxis("x").setBoundaries(0, fPlot.length);
		p.getAxis("y").setBoundaries(0, 80);
		p.setKey(JavaPlot.Key.TOP_RIGHT);
		PlotStyle stl = ((AbstractPlot) p.getPlots().get(0)).getPlotStyle();
		stl.setStyle(Style.LINES);
		stl.setLineType(NamedPlotColor.LIGHT_RED);
		// Outputa terminal gisa bidaltzea aztertu

		// par.set("output", "output.png"); 640, 1080 | 1920,1080
		p.getPostInit().add("set terminal png size  1875,640 enhanced font \"Helvetica,20\"");
		// String dataNorm = hasieraData.substring(0, 2)+"-"+hasieraData.substring(3,
		// 5)+"-"+hasieraData.substring(6);
		// System.out.println(dataNorm);
		// System.out.println("WorkingDir:" + Main.getWorkingDirectory());
		String backSlash = "'";
		backSlash = backSlash.replace("'", "\\");
		String command = "set output '" + Main.getWorkingDirectory() + backSlash + identifikatzailea + "-" + "gertaerak"
				+  ".png'";
		// System.out.println(command);
		// command = "set output '" + Main.getWorkingDirectory() + backSlash
		// +label.replace(" ","_") + ".png'";
		p.getPostInit().add(command);
		// p.setParameters(par);
		// p.setKey(JavaPlot.Key.OFF);
		p.setKey(JavaPlot.Key.OFF);
		// p.set("label", "AAAAAAAAAA");
		// p.getPostInit().add("set key right top Right title 'Legend' box 3");
		// p.getPostInit().add("set y2label 'Y2Label'");
		// p.getPostInit().add("set label 2 '5 meV' at 200,3000");
		// p.set("xlabel", "'x'");
		// stl2.set("set title 'test2'"); Datafile
		// stl2.set("set label 'test3'");
		// p.setMultiTitle("Test");
		// p.getPostInit().add("set key spacing 3");
		// p.getPostInit().add("set key box lt -1 lw 2");
		p.plot();
		int[] hpna = new int[2];
		hpna[0]=maxhpna;
		hpna[1]=hpnaKop;
		return hpna;
	}





}

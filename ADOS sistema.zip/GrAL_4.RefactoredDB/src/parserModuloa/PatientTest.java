/**
 * 
 */
package parserModuloa;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author Eneko
 *
 */
class PatientTest {

	Patient p1;
	String fullEDFPath1 = "A:\\Desktop\\GraL"+"\\input\\" + "800648.edf";
	String fullEDFPath2 = "A:\\Desktop\\GraL"+"\\input\\" + "868342.edf";		
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		p1 = new Patient("paciente 1");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		p1 = new Patient("paciente 1");
	}

	/**
	 * Test method for {@link parserModuloa.Patient#getPatientId()}.
	 */
	@Test
	final void testGetPatientId(){	
		try {	
	        assertEquals("paciente 1", p1.getPatientId());
			System.out.println("--- testGetPatientId: Ok");
			
		} catch (AssertionError e) {
			// TODO: handle exception
			System.out.println("--- testGetPatientId ---");
			System.out.println("t: paciente 1 = s: "+p1.getPatientId());
		}
		
		
	}

	/**
	 * Test method for {@link parserModuloa.Patient#addEstudioOld(java.lang.String)}.
	 */
	@Test
	final void testAddEstudio() {
		try {	
			//p1.addEstudio(fullEDFPath1);
			//p1.addEstudio(fullEDFPath2);
			//p1.addEstudio(fullEDFPath1);
			System.out.println("--- testAddEstudio: Ok");
			
		} catch (AssertionError e) {
			// TODO: handle exception
			System.out.println("--- testAddEstudio ---");
		}
	}

}

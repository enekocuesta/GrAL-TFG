package parserModuloa;

import java.util.ArrayList;
import java.util.HashMap;

import com.panayotis.gnuplot.JavaPlot;
import com.panayotis.gnuplot.plot.AbstractPlot;
import com.panayotis.gnuplot.style.NamedPlotColor;
import com.panayotis.gnuplot.style.PlotStyle;
import com.panayotis.gnuplot.style.Style;

public class testestest {
	private String hasieraData; // DB
	private String hasieraDenbora; // DB
	private String bukaeraData; // DB
	private String bukaeraDenbora; // DB
	private int iraupena; // segundutan
	private ArrayList<Integer> max; // maximos (indexados)
	private ArrayList<Integer> min; // minimos (indexados)
	private HashMap<String, ArrayList<Integer>> seinaleak; // Label eta Balioak
	private HashMap<String, int[][]> pikoak; // Label eta Balioak
	private ArrayList<Sentsorea> sensoreak;
	private boolean dbLoaded;

	
	public void plotByParams(ArrayList<String> params, String idGaixo, boolean highlights) {
		int scalerMax;
		int scalerMin;
		for (String label : seinaleak.keySet()) {
			if (params.contains(label)) {
				
				int[] scaler = getScaler(label);  //Sentsorearen eskala zehazteko
				scalerMax = scaler[0]; //Eskala zehazteko
				scalerMin = scaler[1]; //Eskala zehazteko

				JavaPlot p = new JavaPlot(); //Ploterra sortu
				p.setTitle(label); //Titulua ezarri

				int[][] maxMin = getMaximumMinimum(label); // MaxMin[0][] = Maximum[] || MaxMin[1][] = Minimum[] ||
															// Maximum[0] = second, Maximum[1] = value

				int[][] fPlot;
				if (highlights) {
					fPlot = getValueSecondHighlights(label, maxMin[0][1], maxMin[1][1]); // fPlot[second][value]; balio anomaloak
				} else {
					fPlot = getValueSecond(label); // fPlot[second][value]; balio sinkronizatuak
				}

				// DATUAK ploterran sartu
				p.addPlot(fPlot);
				p.getAxis("x").setLabel("Denbora (s)");
				p.getAxis("y").setLabel("Balioa"); // + a�adir medida en cuestion TODO
				p.getAxis("x").setBoundaries(0, fPlot.length);
				maxMin[0][1] = getMax(fPlot);
				maxMin[1][1] = getMin(fPlot);
				p.getAxis("y").setBoundaries(scalerMin + maxMin[1][1] * 1.25, scalerMax + maxMin[0][1] * 1.25);
				p.setKey(JavaPlot.Key.TOP_RIGHT);
				PlotStyle stl = ((AbstractPlot) p.getPlots().get(0)).getPlotStyle();
				stl.setStyle(Style.LINES);
				stl.setLineType(NamedPlotColor.DARK_BLUE);

				// Maximoak eta minimoak adierazi
				int[][] maxMinL = new int[seinaleak.get(label).size() + 1][1];
				maxMinL[maxMin[1][0]][0] = maxMin[1][1];
				maxMinL[maxMin[0][0]][0] = maxMin[0][1];
				p.addPlot(maxMinL);
				
				//Estiloa ezarri
				PlotStyle stl2 = ((AbstractPlot) p.getPlots().get(1)).getPlotStyle();
				stl2.setStyle(Style.FSTEPS);
				stl2.setLineType(NamedPlotColor.LIGHT_RED);

				// Outputa terminal gisa bidaltzea aztertu
				p.getPostInit().add("set terminal png size  1875,640 enhanced font \"Helvetica,20\"");
				
				String backSlash = "'";
				backSlash = backSlash.replace("'", "\\");
				String command = "set output '" + Main.getWorkingDirectory() + backSlash + idGaixo + "-"
						+ getHDataDB().replace(" ", "-").replace(":", "-") + "__" + label.replace(" ", "-") + ".png'";
				
				p.getPostInit().add(command);
			
				p.setKey(JavaPlot.Key.OFF);
			} else {
				System.out.println("Doesn't contain label: " + label);
			}

		}

	}


	private HashMap<String, String> getHDataDB() {
		// TODO Auto-generated method stub
		return null;
	}


	private int getMin(int[][] fPlot) {
		// TODO Auto-generated method stub
		return 0;
	}


	private int getMax(int[][] fPlot) {
		// TODO Auto-generated method stub
		return 0;
	}


	private int[][] getValueSecond(String label) {
		// TODO Auto-generated method stub
		return null;
	}


	private int[][] getValueSecondHighlights(String label, int i, int j) {
		// TODO Auto-generated method stub
		return null;
	}


	private int[][] getMaximumMinimum(String label) {
		// TODO Auto-generated method stub
		return null;
	}


	private int[] getScaler(String label) {
		// TODO Auto-generated method stub
		return null;
	}
}

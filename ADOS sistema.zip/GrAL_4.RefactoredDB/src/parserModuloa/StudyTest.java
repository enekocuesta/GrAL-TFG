package parserModuloa;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edfParserUtils.EDFParser;
import edfParserUtils.EDFParserResult;

class StudyTest {

	Study s1;
	Study s2;
	String fullEDFPath1 = "A:\\Desktop\\GraL"+"\\input\\" + "800648.edf";
	String fullEDFPath2 = "A:\\Desktop\\GraL"+"\\input\\" + "868342.edf";
	EDFParserResult result = null;
	EDFParserResult result2 = null;
	@BeforeEach
	void setUp() throws Exception {
		s1 = new Study();
		s2 = new Study();
		
		
		
		File f = new File(fullEDFPath1);
		InputStream is = null;
		is = new FileInputStream(f);
		result = EDFParser.parseEDF(is);
		
		f = new File(fullEDFPath2);
		is = null;
		is = new FileInputStream(f);
		result2 = EDFParser.parseEDF(is);
	}

	@AfterEach
	void tearDown() throws Exception {
		s1 = new Study();
		s2 = new Study();
	}

	@Test
	final void testParseData() {
		//s1.parseData(result);
		//s1.parseData(result);
		//s1.parseData(result2);
	}

}

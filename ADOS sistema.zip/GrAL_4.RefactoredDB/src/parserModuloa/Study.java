package parserModuloa;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Timestamp;

import javax.sound.sampled.Line;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

import com.mysql.cj.protocol.InternalTimestamp;
import com.panayotis.gnuplot.GNUPlotParameters;
import com.panayotis.gnuplot.JavaPlot;
import com.panayotis.gnuplot.dataset.FileDataSet;
import com.panayotis.gnuplot.layout.StripeLayout;
import com.panayotis.gnuplot.plot.DataSetPlot;
import com.panayotis.gnuplot.plot.Plot;
import com.panayotis.gnuplot.style.NamedPlotColor;
import com.panayotis.gnuplot.style.PlotColor;
import com.panayotis.gnuplot.style.PlotStyle;
import com.panayotis.gnuplot.style.Style;
import com.panayotis.gnuplot.swing.JPlot;
import com.panayotis.gnuplot.terminal.PostscriptTerminal;
import com.panayotis.gnuplot.utils.Debug;

import datuBasea.DbGalderak;

import com.panayotis.gnuplot.plot.AbstractPlot;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.OptionalDouble;
import java.util.concurrent.TimeUnit;

import edfParserUtils.EDFParserResult;

public class Study {

	private String hasieraData; // DB
	private String hasieraDenbora; // DB
	private String bukaeraData; // DB
	private String bukaeraDenbora; // DB
	private int iraupena; // segundutan
	private ArrayList<Integer> max; // maximos (indexados)
	private ArrayList<Integer> min; // minimos (indexados)
	private HashMap<String, ArrayList<Integer>> seinaleak; // Label eta Balioak
	private HashMap<String, int[][]> pikoak; // Label eta Balioak
	private ArrayList<Sentsorea> sensoreak;
	private boolean dbLoaded;

	public Study() {
		seinaleak = new HashMap<String, ArrayList<Integer>>();
		sensoreak = new ArrayList<Sentsorea>();
		pikoak = new HashMap<String, int[][]>();
		dbLoaded = false;
	}

	public Study(String phData, String pbData) { // Ez du partseatzen
		seinaleak = new HashMap<String, ArrayList<Integer>>();
		sensoreak = new ArrayList<Sentsorea>();
		// Datak esleitu
		System.out.println("loading proba: " + phData + " ::: " + pbData);
		dbLoaded = true;

		// kargatuSentsoreak();
	}

	private void kargatuSentsoreak() {
		// TODO Auto-generated method stub
		// Datu basetik kargatu sentsorea
	}

	public String getHDataDB() {
		// System.out.println("Has To be: 2021-07-24 16:23:50");
		Date pDate = new Date(Integer.parseInt("1" + hasieraData.split("/")[2]),
				Integer.parseInt(hasieraData.split("/")[1]), Integer.parseInt(hasieraData.split("/")[0]),
				Integer.parseInt(hasieraDenbora.split(":")[0]), Integer.parseInt(hasieraDenbora.split(":")[1]),
				Integer.parseInt(hasieraDenbora.split(":")[2]));
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// System.out.println(dateFormat.format(pDate));
		// System.out.println("timestamp: "+ptime);
		return dateFormat.format(pDate);
	}

	public String getBDataDB() {
		// .out.println("Has To be: 2021-07-24 16:23:50");

		Date pDate = new Date(Integer.parseInt("1" + bukaeraData.split("/")[2]),
				Integer.parseInt(bukaeraData.split("/")[1]), Integer.parseInt(bukaeraData.split("/")[0]),
				Integer.parseInt(bukaeraDenbora.split(":")[0]), Integer.parseInt(bukaeraDenbora.split(":")[1]),
				Integer.parseInt(bukaeraDenbora.split(":")[2]));
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// System.out.println(dateFormat.format(pDate));
		// System.out.println("timestamp: "+ptime);
		return dateFormat.format(pDate);
	}

	public void parseDataOld(EDFParserResult result, String gaKodea) {
		// TODO Auto-generated method stub
		hasieraData = result.getHeader().getStartDate();
		hasieraDenbora = result.getHeader().getStartTime();
		initMaxMin();

		dataNorm_Iraup(result); // Bukaera data kalkulatzen du, iraupena, eta normalizatu egiten ditu
		System.out.println("hasiera Data: " + hasieraData);
		System.out.println("hasiera Denbora: " + hasieraDenbora);
		System.out.println("bukaera Data: " + bukaeraData);
		System.out.println("bukaera Denbora: " + bukaeraDenbora);
		System.out.println("Iraupena: " + iraupena + "s");

		// getAllSignals(result);
		// Lehenengo sentsoreen datuak jaso
		System.out.println("Sentsoreen datuak jasotzen");
		getSensors(result);
		getSyncSignalsOld(result, gaKodea);

		printData();
		// getAllSignals(result);

	}

	private void getSensors(EDFParserResult result) {
		// TODO Auto-generated method stub
		if (sentsoreMotak()) { // Sentsore motak gehituta badaude
			gehituSentsoreaWithMotak(result);
		} else {// Bestela
			DbGalderak.sendUpdate("Insert into SentsoreMota values ('ER', 'Esfuerzo Respiratorio')");
			DbGalderak.sendUpdate("Insert into SentsoreMota values ('FR', 'Flujo Respiratorio')");
			DbGalderak.sendUpdate("Insert into SentsoreMota values ('PO', 'Posicion y movimiento')");
			DbGalderak.sendUpdate("Insert into SentsoreMota values ('DO', 'Desaturacion de oxigeno')");
			DbGalderak.sendUpdate("Insert into SentsoreMota values ('SO', 'Sonido')");
			DbGalderak.sendUpdate("Insert into SentsoreMota values ('OTRO', 'Sensor inprevisto')");
			getSensors(result);
		}

	}

	private void gehituSentsoreaWithMotak(EDFParserResult result) {
		String sMota = "";
		int i = 0;
		result.getHeader();
		for (String label : result.getHeader().getChannelLabels()) {
			sMota = "";
			label = normalizatu(label);
			switch (label) {
			case "Abdomen":
				sMota = "ER";
				break;
			case "Actividad":
				sMota = "PO";
				break;
			case "Eje X":
				sMota = "PO";
				break;
			case "Eje Y":
				sMota = "PO";
				break;
			case "Eje Z":
				sMota = "PO";
				break;
			case "Elevacion":
				sMota = "PO";
				break;
			case "Fase RIP":
				sMota = "FR";
				break;
			case "Flujo RIP":
				sMota = "FR";
				break;
			case "Frecuencia respiratoria":
				sMota = "ER";
				break;
			case "Pletismografo":
				sMota = "FR";
				break;
			case "Posicion":
				sMota = "PO";
				break;
			case "Pulso":
				sMota = "ER";
				break;
			case "Presion de mascara":
				sMota = "ER";
				break;
			case "SpO2":
				sMota = "DO";
				break;
			case "SpO2 BB":
				sMota = "DO";
				break;
			case "Suma RIP":
				sMota = "FR";
				break;
			case "Temp":
				sMota = "FR";
				break;
			case "Temp FIRLP8H":
				sMota = "FR";
				break;
			case "Torax":
				sMota = "ER";
				break;
			case "Volumen De audio":
				sMota = "SO";
				break;
			case "Volumen De sonido":
				sMota = "SO";
				break;
			default:
				sMota = "OTRO";
			}
			Sentsorea s = new Sentsorea(i, label, "", "", result.getHeader().getDigitalMin()[i],
					result.getHeader().getDigitalMax()[i], sMota);
			sensoreak.add(s);
			i++;
		}
	}

	private boolean sentsoreMotak() {
		if (DbGalderak.sendWithReturnArray("Select * from SENTSOREMOTA").size() > 0) {
			return true;
		} else {
			return false;
		}
	}

	private void initMaxMin() {
		// TODO Auto-generated method stub
		max = new ArrayList<Integer>(); // Creo que esto solo con cojer el primer valor vale.
		min = new ArrayList<Integer>();

		for (int i = 0; i < 20; i++) {
			max.add(0);
			min.add(0);
		}
	}

	private void printData() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		System.out.println("fecha de inicio: " + hasieraData);
		System.out.println("hora de inicio: " + hasieraDenbora);
		System.out.println("fecha de finalizacion: " + bukaeraData);
		System.out.println("hora de finalizacion: " + bukaeraDenbora);
		System.out.println("duracion (s): " + iraupena);

	}

	// Old
	private void getAllSignals(EDFParserResult result) {
		// TODO Auto-generated method stub
		int index = 0;
		for (String label : result.getHeader().channelLabels) {
			ArrayList<Integer> aux = new ArrayList<Integer>();
			for (short balioa : result.getSignal().getDigitalValues()[index]) {
				// System.out.println("balioa: "+(int)balioa);
				aux.add((int) balioa);
			}
			// Label normalizatua sartzen du, eta seinale balio guztiak esleitzen dizkio
			seinaleak.put(normalizatu(label), aux);
			index++;
		}
		index = 69;
	}

	// New
	private void getSyncSignalsOld(EDFParserResult result, String gaKodea) {
		// TODO Auto-generated method stub
		int index = 0;
		int synker = 1;
		int valorSync = 0;
		int segundero = 0;
		ArrayList<Integer> balioak;
		ArrayList<Integer> acumulator = new ArrayList<Integer>();
		for (String label : result.getHeader().channelLabels) {
			balioak = new ArrayList<Integer>();
			synker = 1;
			max.set(index, 0);
			min.set(index, -1);
			for (double balioa : result.getSignal().getDigitalValues()[index]) { // balio bakoitzeko
				acumulator.add((int) balioa); // siempre lo hace

				if (synker == getMaistazuna(result, index)) { // si ya ha transcurrido un segundo
					valorSync = getValorSync(acumulator); // recoger el valor sincronizado
					acumulator = new ArrayList<Integer>(); // vaciar el acumulador
					balioak.add(valorSync); // adquirir el valor sincronizado
					synker = 1;
					segundero++;
					if (valorSync > max.get(index)) {
						max.set(index, valorSync);
					} else if (valorSync < min.get(index)) {
						min.set(index, valorSync);
					}
					if (!dbLoaded) {
						DbGalderak.sendUpdate("Insert into datuak values(" + "'" + gaKodea + "'," + "'" + getHDataDB() + "',"
								+ index + "," + segundero + "," + valorSync + ")");
					}
				} else {
					synker++;
				}

			}

			System.out.println(index + " : " + label + ": " + getMaistazuna(result, index) + "\t||  max: "
					+ max.get(index) + "\t||  min: " + min.get(index)); // maistazuna y label sin normalizar
			// System.out.println(label+": "+getMaistazuna(result,index));
			// Label normalizatua sartzen du, eta seinale balio guztiak esleitzen dizkio
			seinaleak.put(normalizatu(label), balioak);
			index++;
			segundero = 0;
		}
	}

	private int getValorSync(ArrayList<Integer> acumulator) { // Truncated Mean (mathd)
		// TODO Auto-generated method stub
		int sum = 0;
		int sVal = 0;
		Collections.sort(acumulator);
		// System.out.println("Size: "+acumulator.size());

		if (acumulator.size() < 6) {
			for (int i = 0; i < acumulator.size(); i++) { // por cada valor del acumulador quitando limites
				sum += acumulator.get(i);
				// System.out.println("Valor "+i+": "+acumulator.get(i)); debug
			}
			sVal = (sum / acumulator.size());
			// .out.println("Valor de sVal: "+sVal);

			// Debugging:
			// OptionalDouble avg = acumulator.stream().mapToDouble(i -> i).average();
			// System.out.println("Valor de media: "+ (int)avg.getAsDouble());
			return sVal;
		} else {
			int threshold = (int) Math.ceil(acumulator.size() * 0.125);
			// System.out.println("threshold: "+threshold);
			for (int i = threshold; i < acumulator.size() - threshold; i++) { // por cada valor del acumulador quitando
																				// limites
				sum += acumulator.get(i);
				// System.out.println("Valor "+i+": "+acumulator.get(i)); debug
			}
			sVal = (sum / (acumulator.size() - (threshold - 1) * 2));
			// .out.println("Valor de sVal: "+sVal);

			// Debugging:
			// OptionalDouble avg = acumulator.stream().mapToDouble(i -> i).average();
			// System.out.println("Valor de media: "+ (int)avg.getAsDouble());
			return sVal;
		}

	}

	private int getValorSyncDMA(ArrayList<Integer> acumulator) { // Desviación media absoluta (DMA)
		// TODO Auto-generated method stub
		int sum = 0;
		int media = 0;
		int madAux = 0;
		int mad = 0;
		for (int i = 0; i < acumulator.size(); i++) { // recorre y consigue la suma de todos los elementos
			sum += acumulator.get(i);
		}
		media = sum / acumulator.size(); // Calcula la media

		for (int i = 0; i < acumulator.size(); i++) { // recorre para conseguir el mad Aux que es el valor acumulado de
														// la diferencia entre los elementos del array y la media de los
														// mismos.
			madAux += Math.abs(acumulator.get(i) - media);
		}
		mad = madAux / acumulator.size();
		return mad;

	}

	private int getMaistazuna(EDFParserResult result, int index) {
		// zenbat balio / duration
		int maistazuna = result.getSignal().getDigitalValues()[index].length / iraupena;
		return maistazuna;
	}

	private String normalizatu(String label) {
		// TODO Auto-generated method stub
		switch (label) {
		case "Abdomen         ":
			label = "Abdomen";
			break;
		case "Actividad       ":
			label = "Actividad";
			break;
		case "Eje X           ":
			label = "Eje X";
			break;
		case "Eje Y           ":
			label = "Eje Y";
			break;
		case "Eje Z           ":
			label = "Eje Z";
			break;
		case "Elevaci��n      ":
			label = "Elevacion";
			break;
		case "Elevaci?n       ":
			label = "Elevacion";
			break;
		case "Fase RIP        ":
			label = "Fase RIP";
			break;
		case "Flujo RIP       ":
			label = "Flujo RIP";
			break;
		case "Frec. Resp.     ":
			label = "Frecuencia respiratoria";
			break;
		case "Pletism��grafo  ":
			label = "Pletismografo";
			break;
		case "Pletism?grafo   ":
			label = "Pletismografo";
			break;
		case "Posici?n        ":
			label = "Posicion";
			break;
		case "Posici��n       ":
			label = "Posicion";
			break;
		case "Pulso           ":
			label = "Pulso";
			break;
		case "Presi?n de m?sca":
			label = "Presion de mascara";
			break;
		case "SpO2            ":
			label = "SpO2";
			break;
		case "SpO2 B-B        ":
			label = "SpO2 BB";
			break;
		case "Suma RIP        ":
			label = "Suma RIP";
			break;
		case "Temp            ":
			label = "Temp";
			break;
		case "Temp [FIR-LP: 8H":
			label = "Temp_FIR LP_8H";
			break;
		case "T��rax          ":
			label = "Torax";
			break;
		case "T?rax           ":
			label = "Torax";
			break;
		case "Volumen de Audio":
			label = "Volumen de audio";
			break;
		case "Volumen de sonid":
			label = "Volumen de sonido";
			break;
		case "Temp [FIR-LP: 7H":
			label = "Temp_FIR LP_7H";
			break;
		case "Temp [FIR-LP: 2H":
			label = "Temp_FIR LP_2H";
			break;
		}

		return label;
	}

	private void dataNorm_Iraup(EDFParserResult result) {
		double numSegs = result.getHeader().getNumberOfRecords() * result.getHeader().getDurationOfRecords();
		int nSegs = (int) Math.round(numSegs);

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yy-HH.mm.ss");
		try {
			cal.setTime(sdf.parse(hasieraData + "-" + hasieraDenbora));
			cal.add(Calendar.SECOND, nSegs);
			String formatted = sdf.format(cal.getTime());
			String[] splitted = formatted.split("-");

			this.bukaeraData = splitted[0];
			this.bukaeraDenbora = splitted[1];

			// Convertimos al formato que pide Juanma: 20/05/2000 --- 23:00:00

			this.hasieraData = this.hasieraData.replace(".", "/");
			this.hasieraData = this.hasieraData.replace(".", "/");
			this.bukaeraData = this.bukaeraData.replace(".", "/");

			this.hasieraDenbora = this.hasieraDenbora.replace(".", ":");
			this.hasieraDenbora = this.hasieraDenbora.replace(".", ":");
			this.bukaeraDenbora = this.bukaeraDenbora.replace(".", ":");

			Date startDate = new SimpleDateFormat("dd/MM/yyyy").parse(hasieraData); // Set start date
			Date endDate = new SimpleDateFormat("dd/MM/yyyy").parse(bukaeraData); // Set end date

			SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
			Date hDenbora = format.parse(hasieraDenbora);
			Date bDenbora = format.parse(bukaeraDenbora);
			long difference = bDenbora.getTime() - hDenbora.getTime();

			long duration = endDate.getTime() - startDate.getTime();
			duration = duration + difference;

			iraupena = (int) TimeUnit.MILLISECONDS.toSeconds(duration);
			// long diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(duration);
			// long diffInHours = TimeUnit.MILLISECONDS.toHours(duration);
			// long diffInDays = TimeUnit.MILLISECONDS.toDays(duration);

			// HAS TO BE
			// 36000s
			// 600m
			// 10h

		} catch (ParseException e1) {
			e1.printStackTrace();
			System.out.println("Patient.actualizarInfo():: Problema al parsear las fechas/horas");
		}

	}

	private static JavaPlot defaultTerminal(String gnuplotpath) {
		JavaPlot p = new JavaPlot(gnuplotpath);
		JavaPlot.getDebugger().setLevel(Debug.VERBOSE);

		p.setTitle("Default Terminal Title");
		p.getAxis("x").setLabel("X axis", "Arial", 20);
		p.getAxis("y").setLabel("Y axis");

		p.getAxis("x").setBoundaries(-30, 20);
		p.setKey(JavaPlot.Key.TOP_RIGHT);

		double[][] plot = { { 1, 1.1 }, { 2, 2.2 }, { 3, 3.3 }, { 4, 4.3 } };
		DataSetPlot s = new DataSetPlot(plot);
		p.addPlot(s);
		p.addPlot("besj0(x)*0.12e1");
		PlotStyle stl = ((AbstractPlot) p.getPlots().get(1)).getPlotStyle();
		stl.setStyle(Style.POINTS);
		stl.setLineType(NamedPlotColor.GOLDENROD);
		stl.setPointType(5);
		stl.setPointSize(8);
		p.addPlot("sin(x)");

		p.newGraph();
		p.addPlot("sin(x)");

		p.newGraph3D();
		double[][] plot3d = { { 1, 1.1, 3 }, { 2, 2.2, 3 }, { 3, 3.3, 3.4 }, { 4, 4.3, 5 } };
		p.addPlot(plot3d);

		p.newGraph3D();
		p.addPlot("sin(x)*sin(y)");

		p.setMultiTitle("Global test title");
		StripeLayout lo = new StripeLayout();
		lo.setColumns(9999);
		p.getPage().setLayout(lo);
		p.plot();

		return p;
	}

	public void plotData() {
		// TODO Auto-generated method stub
		System.out.println("Estudio: " + hasieraData + " / " + bukaeraData + " | " + iraupena + "s");
		int i = 0;
		int s;
		int adjuster = 0;
		for (String label : seinaleak.keySet()) {
			// System.out.println(i + " - Label: " + label);

			JavaPlot p = new JavaPlot();
			p.setTitle(label);

			s = 1;
			int[][] fPlot = new int[seinaleak.get(label).size() + 1][1];
			int maxi = 0;
			int mini = 999999;
			int maxiS = 0;
			int miniS = 0;
			for (int valor : seinaleak.get(label)) {
				fPlot[s][0] = valor;
				// System.out.println("valor: "+ valor);
				if (valor > maxi) {
					maxi = valor;
					maxiS = s;
				} else if (valor < mini) {
					mini = valor;
					miniS = s;
				}
				s++;
				// System.out.println("valor: "+ valor + "max: " + max + "min: " + min);
			}
			/*
			 * y-coordinate, use "set size ratio." Suppose the x range is from -5 to 5 that
			 * is a length of 10; the y range is from -1 to 1 that is a length of 2. The
			 * ratio between them should be y/x = 2/10 = 0.2. Therefore, you enter gnuplot>
			 * set size ratio 0.2 gnuplot> plot [-5:5][-1:1] sin(x)*cos(x**2)
			 */

			// testPlot
			/*
			 * fPlot = new int[10][1]; fPlot[0][0] = 1; fPlot[1][0] = 20; fPlot[2][0] = 22;
			 * fPlot[3][0] = 21; fPlot[4][0] = 20; fPlot[5][0] = 19; fPlot[6][0] = 15;
			 * fPlot[7][0] = 14; fPlot[8][0] = 13; fPlot[9][0] = 50;
			 */

			p.addPlot(fPlot);
			p.getAxis("x").setLabel("Tiempo", "Arial", 10);
			p.getAxis("y").setLabel("Valor");
			p.getAxis("x").setBoundaries(0, fPlot.length);
			// p.getAxis("x").setBoundaries(0, 100);
			// p.getAxis("y").setBoundaries(-100,100);
			// System.out.println("maxi: " + maxi + "mini: " + mini);
			maxi = getMax(fPlot);
			mini = getMin(fPlot);
			// System.out.println("maxi: " + maxi + "mini: " + mini);

			p.getAxis("y").setBoundaries(mini * 2, maxi * 2);
			p.setKey(JavaPlot.Key.TOP_RIGHT);
			PlotStyle stl = ((AbstractPlot) p.getPlots().get(0)).getPlotStyle();
			// tl.setStyle(Style.LINES);
			stl.setStyle(Style.LINES);
			// stl.setPointSize(1);
			// JavaPlot.getDebugger().setLevel(Debug.VERBOSE);
			stl.setLineType(NamedPlotColor.DARK_BLUE);

			int[][] maxMin = new int[seinaleak.get(label).size() + 1][1];
			maxMin[miniS][0] = mini;
			maxMin[maxiS][0] = maxi;
			p.addPlot(maxMin);

			PlotStyle stl2 = ((AbstractPlot) p.getPlots().get(1)).getPlotStyle();
			// tl.setStyle(Style.LINES);
			// stl2.setStyle(Style.LINES);
			stl2.setStyle(Style.FSTEPS);
			stl2.setLineType(NamedPlotColor.LIGHT_RED);

			// stl2.setStyle(Style.POINTS);
			// stl2.setPointType(50);
			// stl2.setLineType(2);
			// stl2.setPointSize(20);

			// Outputa terminal gisa bidaltzea aztertu

			// par.set("output", "output.png");
			p.getPostInit().add("set terminal png size 1920,1080 enhanced font \"Helvetica,20\"");
			// String dataNorm = hasieraData.substring(0, 2)+"-"+hasieraData.substring(3,
			// 5)+"-"+hasieraData.substring(6);
			// System.out.println(dataNorm);
			p.getPostInit().add("set output '" + Main.getWorkingDirectory() + "\\Gnuplot\\output\\" + getHDataDB() + "_"
					+ label + ".png'");
			// p.setParameters(par);
			p.plot();
			i++;
		}

	}

	private int getMin(int[][] fPlot) {
		// TODO Auto-generated method stub
		int min = fPlot[0][0];
		for (int i = 0; i < fPlot.length; i++) {

			if (fPlot[i][0] < min) {
				min = fPlot[i][0];
			}
		}
		return min;
	}

	private int getMax(int[][] fPlot) {
		// TODO Auto-generated method stub
		int max = fPlot[0][0];
		for (int i = 0; i < fPlot.length; i++) {

			if (fPlot[i][0] > max) {
				max = fPlot[i][0];
			}
		}

		return max;
	}

	public void parseData(EDFParserResult result, String idGaixo) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		hasieraData = result.getHeader().getStartDate();
		hasieraDenbora = result.getHeader().getStartTime();
		initMaxMin();

		dataNorm_Iraup(result); // Bukaera data kalkulatzen du, iraupena, eta normalizatu egiten ditu
		System.out.println("hasiera Data: " + hasieraData);
		System.out.println("hasiera Denbora: " + hasieraDenbora);
		System.out.println("bukaera Data: " + bukaeraData);
		System.out.println("bukaera Denbora: " + bukaeraDenbora);
		System.out.println("Iraupena: " + iraupena + "s");

		// getAllSignals(result);
		// Lehenengo sentsoreen datuak jaso
		System.out.println("Sentsoreen datuak jasotzen");
		getSensors(result); // database
		getSyncSignals(result, idGaixo);

		printData();
		// getAllSignals(result);
	}

	private void getSyncSignals(EDFParserResult result, String idGaixo) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		int index = 0;
		int synker = 1;
		int valorSync = 0;
		int segundero = 0;
		ArrayList<Integer> balioak;
		ArrayList<Integer> acumulator = new ArrayList<Integer>();
		for (String label : result.getHeader().channelLabels) {
			balioak = new ArrayList<Integer>();
			synker = 1;
			max.set(index, 0);
			min.set(index, -1);
			for (double balioa : result.getSignal().getDigitalValues()[index]) { // balio bakoitzeko
				acumulator.add((int) balioa); // siempre lo hace

				if (synker == getMaistazuna(result, index)) { // si ya ha transcurrido un segundo
					valorSync = getValorSync(acumulator); // recoger el valor sincronizado
					acumulator = new ArrayList<Integer>(); // vaciar el acumulador
					balioak.add(valorSync); // adquirir el valor sincronizado
					synker = 1;
					segundero++;
					if (valorSync > max.get(index)) {
						max.set(index, valorSync);
					} else if (valorSync < min.get(index)) {
						min.set(index, valorSync);
					}

				} else {
					synker++;
				}

			}

			System.out.println(index + " : " + label + ": " + getMaistazuna(result, index) + "\t||  max: "
					+ max.get(index) + "\t||  min: " + min.get(index)); // maistazuna y label sin normalizar
			// System.out.println(label+": "+getMaistazuna(result,index));
			// Label normalizatua sartzen du, eta seinale balio guztiak esleitzen dizkio
			seinaleak.put(normalizatu(label), balioak);
			index++;
			segundero = 0;
		}
	}

	public String getIraupen() {
		// TODO Auto-generated method stub

		return Integer.toString(iraupena);
	}

	public String getHData() {
		// TODO Auto-generated method stub
		return hasieraData + " " + hasieraDenbora;
	}

	public String getBData() {
		// TODO Auto-generated method stub
		return bukaeraData + " " + bukaeraDenbora;
	}

	public HashMap<String, ArrayList<Integer>> getData() {
		// TODO Auto-generated method stub
		return seinaleak;
	}

	private int[][] getValueSecond(String label) {
		// TODO Auto-generated method stub
		int s = 1;
		int[][] fPlot = new int[seinaleak.get(label).size() + 1][1];
		for (int valor : seinaleak.get(label)) {
			fPlot[s][0] = valor;
			s++;
		}
		return fPlot;
	}

	private int[][] getMaximumMinimum(String label) {// MaxMin[0][] = Maximum[] || MaxMin[1][] = Minimum[] || Maximum[0]
														// = second, Maximum[1] = value
		// No contar el 0 como minimo en los siguientes:
		// Eje s
		int[][] maxMin = new int[2][2];
		int s = 1;
		int maxi = 0;
		int mini = 999999999;
		int maxiS = 0;
		int miniS = 0;
		for (int valor : seinaleak.get(label)) {
			if (valor > maxi) {
				maxi = valor;
				maxiS = s;
			} else if (valor < mini) {
				mini = valor;
				miniS = s;
			}
			s++;
		}
		maxMin[0][0] = maxiS;
		maxMin[0][1] = maxi;
		maxMin[1][0] = miniS;
		maxMin[1][1] = mini;
		return maxMin;
	}

	public void plotByParams(ArrayList<String> params, String idGaixo, boolean highlights) {
		// TODO Auto-generated method stub
		// System.out.println("Plotting by Params: " + params);
		int seinaleKodea = 0;
		int scalerMax;
		int scalerMin;
		for (String label : seinaleak.keySet()) {
			if (params.contains(label)) {

				scalerMax = getScaler(label)[0];
				scalerMin = getScaler(label)[1];

				JavaPlot p = new JavaPlot();
				p.setTitle(label);

				int[][] maxMin = getMaximumMinimum(label); // MaxMin[0][] = Maximum[] || MaxMin[1][] = Minimum[] ||
															// Maximum[0] = second, Maximum[1] = value

				int[][] fPlot;
				if (highlights) {
					fPlot = getValueSecondHighlights(label, maxMin[0][1], maxMin[1][1]); // fPlot[second][value]
				} else {
					fPlot = getValueSecond(label); // fPlot[second][value]
				}

				// DATA
				p.addPlot(fPlot);
				p.getAxis("x").setLabel("Denbora (s)");
				p.getAxis("y").setLabel("Balioa"); // + añadir medida en cuestion TODO
				p.getAxis("x").setBoundaries(0, fPlot.length);
				maxMin[0][1] = getMax(fPlot);
				maxMin[1][1] = getMin(fPlot);
				p.getAxis("y").setBoundaries(scalerMin + maxMin[1][1] * 1.25, scalerMax + maxMin[0][1] * 1.25);
				p.setKey(JavaPlot.Key.TOP_RIGHT);
				PlotStyle stl = ((AbstractPlot) p.getPlots().get(0)).getPlotStyle();
				stl.setStyle(Style.LINES);
				stl.setLineType(NamedPlotColor.DARK_BLUE);

				// MaxMins
				int[][] maxMinL = new int[seinaleak.get(label).size() + 1][1];
				maxMinL[maxMin[1][0]][0] = maxMin[1][1];
				maxMinL[maxMin[0][0]][0] = maxMin[0][1];
				p.addPlot(maxMinL);

				PlotStyle stl2 = ((AbstractPlot) p.getPlots().get(1)).getPlotStyle();
				stl2.setStyle(Style.FSTEPS);
				stl2.setLineType(NamedPlotColor.LIGHT_RED);

				// Outputa terminal gisa bidaltzea aztertu

				// par.set("output", "output.png"); 640, 1080 | 1920,1080
				p.getPostInit().add("set terminal png size  1875,640 enhanced font \"Helvetica,20\"");
				// String dataNorm = hasieraData.substring(0, 2)+"-"+hasieraData.substring(3,
				// 5)+"-"+hasieraData.substring(6);
				// System.out.println(dataNorm);
				// System.out.println("WorkingDir:" + Main.getWorkingDirectory());
				String backSlash = "'";
				backSlash = backSlash.replace("'", "\\");
				String command = "set output '" + Main.getWorkingDirectory() + backSlash + idGaixo + "-"
						+ getHDataDB().replace(" ", "-").replace(":", "-") + "__" + label.replace(" ", "-") + ".png'";
				// System.out.println(command);
				// command = "set output '" + Main.getWorkingDirectory() + backSlash
				// +label.replace(" ","_") + ".png'";
				p.getPostInit().add(command);
				// p.setParameters(par);
				// p.setKey(JavaPlot.Key.OFF);
				p.setKey(JavaPlot.Key.OFF);
				// p.set("label", "AAAAAAAAAA");
				// p.getPostInit().add("set key right top Right title 'Legend' box 3");
				// p.getPostInit().add("set y2label 'Y2Label'");
				// p.getPostInit().add("set label 2 '5 meV' at 200,3000");
				// p.set("xlabel", "'x'");
				// stl2.set("set title 'test2'"); Datafile
				// stl2.set("set label 'test3'");
				// p.setMultiTitle("Test");
				// p.getPostInit().add("set key spacing 3");
				// p.getPostInit().add("set key box lt -1 lw 2");
				p.plot();
				seinaleKodea++;
			} else {
				System.out.println("Doesn't contain label: " + label);
			}

		}

	}

	
	
	private void uploadSensors() {
		// TODO Auto-generated method stub

	}

	private void uploadToDatabase(String idGaixo, ArrayList<String> selectedParameters) {
		// TODO quitar este if cuando vaya a hacer pruebas
		// dar la opcion de elegir cuales subir tambien
		int[][] fPlot;

		for (String label : selectedParameters) {
			// if (label.equals("Temp") || label.equals("SpO2")) {
			//
			// }
			int seinalekodea = getSeinalekodea(label);
			if (pikoak.keySet().contains(label)) {
				fPlot = pikoak.get(label); // If there isn't nothing i think i should get highlights from here
			} else {
				int[][] maxMin = getMaximumMinimum(label); // MaxMin[0][] = Maximum[] || MaxMin[1][] = Minimum[] ||
				fPlot = getValueSecondHighlights(label, maxMin[0][1], maxMin[1][1]); // fPlot[second][value]
			}
			for (int second = 0; second < fPlot.length; second++) {
				if (fPlot[second][0] != 0) {
					
//dataLineExists(String gertaeraKodea, String patientId, String hasieraData, String denbMarka, String sKodea) {
	
					if(dataLineExists(idGaixo, getHDataDB(), Integer.toString(second),Integer.toString(seinalekodea))) {
						System.out.println("Update datuak set datua = '" + fPlot[second][0] + "'" + " where gaKodea = '"
								+ idGaixo + "'" + " and pData = '" + this.getHDataDB() + "'" + " and denboraMarka='"
								+ Integer.toString(second) + "'"+" and sKodea='"+Integer.toString(seinalekodea)+"'");

						
						DbGalderak.sendUpdate("Update datuak set datua = '" + fPlot[second][0] + "'" + " where gaKodea = '"
								+ idGaixo + "'" + " and pData = '" + this.getHDataDB() + "'" + " and denboraMarka='"
								+ Integer.toString(second) + "'"+" and sKodea='"+Integer.toString(seinalekodea)+"'");
					}else {
						System.out.println(
								"Insert into datuak (gaKodea, pData, sKodea, denboraMarka, datua) values(" + idGaixo + ','
										+ getHDataDB() + ',' + seinalekodea + ',' + second + ',' + fPlot[second][0] + ')');
						DbGalderak.sendUpdate("Insert into datuak (gaKodea, pData, sKodea, denboraMarka, datua) values(" + "'"
								+ idGaixo + "'," + "'" + getHDataDB() + "'," + seinalekodea + "," + second + ","
								+ fPlot[second][0] + ")");
					}
				}
			}
		}
		/*
		 * for (String label : pikoak.keySet()) { // if (label.equals("Temp") ||
		 * label.equals("SpO2")) { // // } if (selectedParameters.contains(label)) { int
		 * seinalekodea = getSeinalekodea(label); fPlot = pikoak.get(label); // If there
		 * isn't nothing i think i should get highlights from here for (int second = 0;
		 * second < fPlot.length; second++) { if (fPlot[second][0] != 0) { System.out.
		 * println("Insert into datuak (gaKodea, pData, sKodea, denboraMarka, datua) values("
		 * + idGaixo + ',' + getHDataDB() + ',' + seinalekodea + ',' + second + ',' +
		 * fPlot[second][0] + ')'); DbGalderak.
		 * send("Insert into datuak (gaKodea, pData, sKodea, denboraMarka, datua) values("
		 * + "'" + idGaixo + "'," + "'" + getHDataDB() + "'," + seinalekodea + "," +
		 * second + "," + fPlot[second][0] + ")"); } } } }
		 */
	}

	private int getSeinalekodea(String label) {
		// Konsulta con la datubase
		String kodea = DbGalderak.sendWithReturnArray("Select kodea from sentsorea where izena = '" + label + "'")
				.get(0).get(0);
		return Integer.parseInt(kodea);
	}

	private int[] getScaler(String label) {
		int[] result = new int[2];
		switch (label) { // NO VALE PARA LOS EJES, PULSO Y SPO2BB SI
		case "Eje Y":
			// adjusterMax = -700;
			// adjusterMin = 200;
			break;
		case "Eje X":
			break;
		case "Eje Z":
			break;
		case "Elevacion":
			break;
		case "Fase RIP":
			break;
		case "Frecuencia respiratoria":
			break;
		case "Pletismografo":
			break;
		case "Pulso":
			// adjusterMax = 0;
			// adjusterMin = 0;
			break;
		case "SpO2":
			result[0] = -15;
			result[1] = 50;
			break;
		case "SpO2 BB":
			result[0] = -15;
			result[1] = 50;
			break;
		default:
			result[0] = 0;
			result[1] = 0;

		}
		return result;
	}

	public void rePlotByParams(ArrayList<String> selectedParameters, int from, int to, String idGaixo,
			boolean highlights) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		// System.out.println("Plotting by Params: " + selectedParameters);
		int i = 0;
		int scalerMin;
		int scalerMax;
		for (String label : seinaleak.keySet()) {
			if (selectedParameters.contains(label)) {
				// System.out.println("Plotting: " + label);
				scalerMax = getScaler(label)[0];
				scalerMin = getScaler(label)[1];
				JavaPlot p = new JavaPlot();
				p.setTitle(label);

				int[][] maxMin = getMaximumMinimum(label); // MaxMin[0][] = Maximum[] || MaxMin[1][] = Minimum[] ||
															// Maximum[0] = second, Maximum[1] = value

				int[][] fPlot;
				if (highlights) {
					fPlot = getValueSecondHighlights(label, maxMin[0][1], maxMin[1][1]); // fPlot[second][value]
				} else {
					fPlot = getValueSecond(label); // fPlot[second][value]
				}

				/*
				 * y-coordinate, use "set size ratio." Suppose the x range is from -5 to 5 that
				 * is a length of 10; the y range is from -1 to 1 that is a length of 2. The
				 * ratio between them should be y/x = 2/10 = 0.2. Therefore, you enter gnuplot>
				 * set size ratio 0.2 gnuplot> plot [-5:5][-1:1] sin(x)*cos(x**2)
				 */

				// testPlot
				/*
				 * fPlot = new int[10][1]; fPlot[0][0] = 1; fPlot[1][0] = 20; fPlot[2][0] = 22;
				 * fPlot[3][0] = 21; fPlot[4][0] = 20; fPlot[5][0] = 19; fPlot[6][0] = 15;
				 * fPlot[7][0] = 14; fPlot[8][0] = 13; fPlot[9][0] = 50;
				 */

				// DATA
				p.addPlot(fPlot);
				p.getAxis("x").setLabel("Tiempo (s)");
				p.getAxis("y").setLabel("Valor"); // + añadir medida en cuestion TODO

				// p.getAxis("x").setBoundaries(0, 100);
				// p.getAxis("y").setBoundaries(-100,100);
				// System.out.println("maxi: " + maxMin[0][1] + "mini: " + maxMin[1][1]);
				maxMin[0][1] = getMax(fPlot);
				maxMin[1][1] = getMin(fPlot);
				// System.out.println("maxi: " + maxMin[0][1] + "mini: " + maxMin[1][1]);

				p.getAxis("y").setBoundaries(scalerMin + maxMin[1][1] * 1.25, scalerMax + maxMin[0][1] * 1.25);

				if (from > 0 && from < fPlot.length && to > 0 && to < fPlot.length) {
					p.getAxis("x").setBoundaries(from, to); // Caso bien
				} else if (from > 0 && from < fPlot.length) {
					p.getAxis("x").setBoundaries(from, fPlot.length); // caso to no valido
				} else if (to > 0 && to < fPlot.length) {
					p.getAxis("x").setBoundaries(0, to); // Caso from no valido
				} else {
					p.getAxis("x").setBoundaries(0, fPlot.length); // el resto
				}

				p.setKey(JavaPlot.Key.TOP_RIGHT);
				// p.set("Maximun/Minimum", "Values");

				PlotStyle stl = ((AbstractPlot) p.getPlots().get(0)).getPlotStyle();
				// tl.setStyle(Style.LINES);
				stl.setStyle(Style.LINES);
				// stl.setPointSize(1);
				// JavaPlot.getDebugger().setLevel(Debug.VERBOSE);
				stl.setLineType(NamedPlotColor.DARK_BLUE);

				// MaxMins
				int[][] maxMinL = new int[seinaleak.get(label).size() + 1][1];
				maxMinL[maxMin[1][0]][0] = maxMin[1][1];
				maxMinL[maxMin[0][0]][0] = maxMin[0][1];

				p.addPlot(maxMinL);

				PlotStyle stl2 = ((AbstractPlot) p.getPlots().get(1)).getPlotStyle();
				// tl.setStyle(Style.LINES);
				// stl2.setStyle(Style.LINES);
				stl2.setStyle(Style.FSTEPS);
				stl2.setLineType(NamedPlotColor.LIGHT_RED);
				// stl2.setStyle(Style.POINTS);
				// stl2.setPointType(50);
				// stl2.setLineType(2);
				// stl2.setPointSize(20);

				// Outputa terminal gisa bidaltzea aztertu

				// par.set("output", "output.png"); 640, 1080 | 1920,1080
				p.getPostInit().add("set terminal png size  1875,640 enhanced font \"Helvetica,20\"");
				// String dataNorm = hasieraData.substring(0, 2)+"-"+hasieraData.substring(3,
				// 5)+"-"+hasieraData.substring(6);
				// System.out.println(dataNorm);
				// System.out.println("WorkingDir:" + Main.getWorkingDirectory());
				String backSlash = "'";
				backSlash = backSlash.replace("'", "\\");
				String command = "set output '" + Main.getWorkingDirectory() + backSlash + idGaixo + "-"
						+ getHDataDB().replace(" ", "-").replace(":", "-") + "__" + label.replace(" ", "-") + "--Replot"
						+ ".png'";
				// System.out.println(command);
				// command = "set output '" + Main.getWorkingDirectory() + backSlash
				// +label.replace(" ","_") + ".png'";
				p.getPostInit().add(command);
				// p.setParameters(par);
				// p.setKey(JavaPlot.Key.OFF);
				p.setKey(JavaPlot.Key.OFF);
				// p.set("label", "AAAAAAAAAA");
				// p.getPostInit().add("set key right top Right title 'Legend' box 3");
				// p.getPostInit().add("set y2label 'Y2Label'");
				// p.getPostInit().add("set label 2 '5 meV' at 200,3000");
				// p.set("xlabel", "'x'");
				// stl2.set("set title 'test2'"); Datafile
				// stl2.set("set label 'test3'");
				// p.setMultiTitle("Test");
				// p.getPostInit().add("set key spacing 3");
				// p.getPostInit().add("set key box lt -1 lw 2");
				p.plot();
				i++;
			} else {
				System.out.println("Doesn't contain label: " + label);
			}

		}
	}

	private int[][] getValueSecondHighlights(String label, int max, int min) {
		// TODO Auto-generated method stub
		// Recorrer valores
		// int s = 1;
		// int[][] fPlot = getValueSecondPicos(label, max, min);
		// int[][] fPlotSecs = new int[seinaleak.get(label).size() + 1][1];
		// System.out.println(fPlot.length);
		int[][] fPlot = new int[seinaleak.get(label).size() + 1][1];
		int from = 0;
		int to = 0;
		System.out.println(label + ":");
		System.out.println((max * Main.getThreshold() / 100) + " < VALUE < " + (min * Main.getThreshold() / 100));
		for (int i = 0; i < seinaleak.get(label).size(); i++) { // Recorrer los valores
			if (seinaleak.get(label).get(i) < min * Main.getThreshold() / 100
					|| seinaleak.get(label).get(i) > max * Main.getThreshold() / 100) { // Si es mas
				/*
				 * if(seinaleak.get(label).get(i) < min * Main.getThreshold() / 100) {
				 * System.out.println(seinaleak.get(label).get(i) + " < " + (min *
				 * Main.getThreshold() / 100 )); }else {
				 * System.out.println(seinaleak.get(label).get(i) + " > " + (max *
				 * Main.getThreshold() / 100)); }
				 */
				// pequeño que
				// el 25% del
				// minimo se
				// cuenta
				// Insertar los valores de alrededor
				// Comprobar los margenes
				if (i - Main.getIntervalSecs() >= 0) {
					from = i - Main.getIntervalSecs();
				} else {
					from = 0;
				}
				if (i + Main.getIntervalSecs() < seinaleak.get(label).size()) {
					to = i + Main.getIntervalSecs();
				} else {
					to = seinaleak.get(label).size() - 1;
				}

				for (from = from; from <= to; from++) {
					fPlot[from + 1][0] = seinaleak.get(label).get(from);

				}
				i = to;
			} else { // SI NO SE GUARDA EL VALOR
				// System.out.println(" NOT entered: " + seinaleak.get(label).get(i));
			}
		}
		pikoak.put(label, fPlot);
		return fPlot;

	}

	public void uploadPicos(String name, ArrayList<String> selectedParameters) {
		uploadToDatabase(name, selectedParameters);
		uploadSensors();
	}

	public void uploadEvents(String patientId) {
		// TODO Auto-generated method stub
		File f1 = prepareCSV(patientId); // changes time and duration formats, and changes the event name to database
											// event code
		if (f1 != null) {

		}
	}

	private File prepareCSV(String patientId) {
		// TODO Auto-generated method stub
		ArrayList<String> lines = new ArrayList<String>();
		String line = null;
		try {
			JFileChooser f = new JFileChooser();
			f.setDialogTitle("Selecciona el CSV de los eventos");
			f.setFileSelectionMode(JFileChooser.FILES_ONLY);
			f.showSaveDialog(null);
			String csv = f.getSelectedFile().getName().split(".csv")[0];
			if (patientId.equals(csv)) {
				// C:\Users\Eneko Cuesta\Desktop\KLASE\GraL\Input\800648.edf
				File f1 = f.getSelectedFile();
				FileReader fr = new FileReader(f1);
				BufferedReader br = new BufferedReader(fr);

				while ((line = br.readLine()) != null) {
					String time;
					String duration;
					if (line.contains("Hipopnea")) {
						time = line.split(";")[1];
						duration = line.split(";")[2];

						line = line.replace("Hipopnea", "5"); // TODO cojer el 5 del datubase
						line = line.replace(time, turn2SecondsTime(time));
						line = line.replace(duration, turn2SecondsDuration(duration));
						line = line.replace("Temp", "16");   //TODO añadir sumarip flujorip
						line = line.replace("Flujo RIP", "7");
						lines.add(line + "\n");
						igoLerroaDatuBasera(patientId, line);
					}else if(line.split(";")[0].contains("5;")) { //Solo las hipoapneas
						igoLerroaDatuBasera(patientId, line);
					}

				}

				fr.close();
				br.close();

				FileWriter fw = new FileWriter(f1);
				BufferedWriter out = new BufferedWriter(fw);
				for (String s : lines)
					out.write(s);
				out.flush();
				out.close();
				return f1;
			} else {
				System.out.println("Couldn't upload becouse csv file does not correspond to the edf file");
			}

		} catch (Exception ex) {
			//ex.printStackTrace();
			//System.out.println("Couldn't upload because of an error");
		}
		return null;
	}

	private void igoLerroaDatuBasera(String patientId, String line) {
		// TODO Auto-generated method stub
		// SELECT * FROM `datuak` WHERE gaKodea = '868342' and denboraMarka='79206'
		for (int i = 0; i <= Integer.parseInt(line.split(";")[2]); i++) {
			// Integer.toString(Integer.parseInt(line.split(";")[1])+0);

			if(dataLineExists(patientId, this.getHDataDB(), Integer.toString(Integer.parseInt(line.split(";")[1]) + i), line.split(";")[3] )) {
				System.out.println("Update datuak set gertaera = '" + line.split(";")[0] + "'" + " where gaKodea = '"
						+ patientId + "'" + " and pData = '" + this.getHDataDB() + "'" + " and denboraMarka='"
						+ Integer.toString(Integer.parseInt(line.split(";")[1]) + i) + "'"+" and sKodea='"+line.split(";")[3]+"'");

				
				DbGalderak.sendUpdate("Update datuak set gertaera = '" + line.split(";")[0] + "'" + " where gaKodea = '"
						+ patientId + "'" + " and pData = '" + this.getHDataDB() + "'" + " and denboraMarka='"
						+ Integer.toString(Integer.parseInt(line.split(";")[1]) + i) + "'"+" and sKodea='"+line.split(";")[3]+"'");
			}else {
				System.out.println("Insert into datuak values('"+patientId+"', '"+this.getHDataDB() +"', '"+line.split(";")[3]+"', '"+Integer.toString(Integer.parseInt(line.split(";")[1]) + i)+"', null, '"+line.split(";")[0]+"')");
				DbGalderak.sendUpdate("Insert into datuak values('"+patientId+"', '"+this.getHDataDB() +"', '"+line.split(";")[3]+"', '"+Integer.toString(Integer.parseInt(line.split(";")[1]) + i)+"', null, '"+line.split(";")[0]+"')");
			}
			
		}

	}

	private boolean dataLineExists(String patientId, String hasieraData, String denbMarka, String sKodea) {

		ArrayList<ArrayList<String>> lista = new ArrayList<ArrayList<String>>();
		lista = DbGalderak.sendWithReturnArray("Select * from Datuak where gaKodea='"+patientId+"' and pData='"+hasieraData+"' and denboraMarka='"+denbMarka+"' and sKodea='"+sKodea+"'");

		if(lista.isEmpty()) {
			return false;
		}else {
			return true;
		}
	}

	private String turn2SecondsDuration(String duration) {
		int minute = 0;
		int seconds = 0;
		if (duration.contains("m")) {
			duration = duration.replace("m", " ");
			minute = Integer.parseInt(duration.split("  ")[0]) * 60;
			seconds = Integer.parseInt(duration.split("  ")[1].split("s")[0]) + minute;
		} else {
			seconds = Integer.parseInt(duration.split("s")[0]) + minute;
		}

		return Integer.toString(seconds);

	}

	private String turn2SecondsTime(String time) {
		// TODO tengo que cambiar lo de la hora e inicializarlo con la hasiera denbora
		// en segundos (time-hdenbora)
		int seconds = date2Seconds(time);
		int probaStartSec = date2Seconds(hasieraDenbora);

		String dif;

		System.out.println("time: " + time + "    start: " + hasieraDenbora);

		if (seconds < probaStartSec) {
			dif = Integer.toString(seconds + 1 + date2Seconds("23:59:59") - probaStartSec);
		} else {
			dif = Integer.toString(Math.abs(seconds - probaStartSec));

		}
		System.out.println(dif);
		return dif;
	}

	private int date2Seconds(String time) {
		// Integer.parseInt(hasieraDenbora.split(":")[2]) +
		// (Integer.parseInt(hasieraDenbora.split(":")[1]) * 60)
		// + (Integer.parseInt(hasieraDenbora.split(":")[0]) * 3600);
		return Integer.parseInt(time.split(":")[2]) + (Integer.parseInt(time.split(":")[1]) * 60)
				+ (Integer.parseInt(time.split(":")[0]) * 3600);
	}

	/*
	 * public void plotByParamsHighlights(ArrayList<String> selectedParameters,
	 * String idGaixo) { // TODO Auto-generated method stub // TODO Auto-generated
	 * method stub // System.out.println("Plotting by Params: " +
	 * selectedParameters); int i = 0; int adjusterMax = 0; int adjusterMin = 0; for
	 * (String label : seinaleak.keySet()) { if (selectedParameters.contains(label))
	 * { // System.out.println("Plotting Highlights: " + label);
	 * 
	 * JavaPlot p = new JavaPlot(); p.setTitle(label + " Highlights");
	 * 
	 * int[][] maxMin = getMaximumMinimum(label); // MaxMin[0][] = Maximum[] ||
	 * MaxMin[1][] = Minimum[] || // Maximum[0] = second, Maximum[1] = value int[][]
	 * fPlot = getValueSecondHighlights(label, maxMin[0][1], maxMin[1][1]); //
	 * fPlot[second][value]
	 * 
	 * /* maxMin[0][0] = maxiS; maxMin[0][1] = maxi; maxMin[1][0] = miniS;
	 * maxMin[1][1]= mini; y-coordinate, use "set size ratio." Suppose the x range
	 * is from -5 to 5 that is a length of 10; the y range is from -1 to 1 that is a
	 * length of 2. The ratio between them should be y/x = 2/10 = 0.2. Therefore,
	 * you enter gnuplot> set size ratio 0.2 gnuplot> plot [-5:5][-1:1]
	 * sin(x)*cos(x**2)
	 */

	// testPlot
	/*
	 * fPlot = new int[10][1]; fPlot[0][0] = 1; fPlot[1][0] = 20; fPlot[2][0] = 22;
	 * fPlot[3][0] = 21; fPlot[4][0] = 20; fPlot[5][0] = 19; fPlot[6][0] = 15;
	 * fPlot[7][0] = 14; fPlot[8][0] = 13; fPlot[9][0] = 50;
	 */

	// DATA
	/*
	 * p.addPlot(fPlot); p.getAxis("x").setLabel("Tiempo (s)");
	 * p.getAxis("y").setLabel("Valor"); // + añadir medida en cuestion TODO
	 * p.getAxis("x").setBoundaries(0, fPlot.length); //
	 * p.getAxis("x").setBoundaries(0, 100); //
	 * p.getAxis("y").setBoundaries(-100,100); // System.out.println("maxi: " +
	 * maxMin[0][1] + "mini: " + maxMin[1][1]); maxMin[0][1] = getMax(fPlot);
	 * maxMin[1][1] = getMin(fPlot); // System.out.println("maxi: " + maxMin[0][1] +
	 * "mini: " + maxMin[1][1]); System.out.println(label); switch (label) { // NO
	 * VALE PARA LOS EJES, PULSO Y SPO2BB SI case "Eje Y": adjusterMax = -700;
	 * adjusterMin = 200; break; case "Eje X": break; case "Eje Z": break; case
	 * "Elevacion": break; case "Fase RIP": break; case "Frecuencia respiratoria":
	 * break; case "Pletismografo": break; case "Pulso": adjusterMax = 0;
	 * adjusterMin = 0; break; case "SpO2": adjusterMax = -15; adjusterMin = 50;
	 * break; case "SpO2 BB": adjusterMax = -15; adjusterMin = 50; break; default:
	 * adjusterMax = 0; adjusterMin = 0; } p.getAxis("y").setBoundaries(adjusterMin
	 * + maxMin[1][1] * 1.25, adjusterMax + maxMin[0][1] * 1.25);
	 * p.setKey(JavaPlot.Key.TOP_RIGHT); // p.set("Maximun/Minimum", "Values");
	 * 
	 * PlotStyle stl = ((AbstractPlot) p.getPlots().get(0)).getPlotStyle(); //
	 * tl.setStyle(Style.LINES); stl.setStyle(Style.LINES); // stl.setPointSize(1);
	 * // JavaPlot.getDebugger().setLevel(Debug.VERBOSE);
	 * stl.setLineType(NamedPlotColor.DARK_BLUE);
	 * 
	 * // MaxMins int[][] maxMinL = new int[seinaleak.get(label).size() + 1][1];
	 * maxMinL[maxMin[1][0]][0] = maxMin[1][1]; maxMinL[maxMin[0][0]][0] =
	 * maxMin[0][1];
	 * 
	 * p.addPlot(maxMinL);
	 * 
	 * PlotStyle stl2 = ((AbstractPlot) p.getPlots().get(1)).getPlotStyle(); //
	 * tl.setStyle(Style.LINES); // stl2.setStyle(Style.LINES);
	 * stl2.setStyle(Style.FSTEPS); stl2.setLineType(NamedPlotColor.LIGHT_RED); //
	 * stl2.setStyle(Style.POINTS); // stl2.setPointType(50); //
	 * stl2.setLineType(2); // stl2.setPointSize(20);
	 * 
	 * // Outputa terminal gisa bidaltzea aztertu
	 * 
	 * // par.set("output", "output.png"); 640, 1080 | 1920,1080 p.getPostInit().
	 * add("set terminal png size  1875,640 enhanced font \"Helvetica,20\""); //
	 * String dataNorm = hasieraData.substring(0, 2)+"-"+hasieraData.substring(3, //
	 * 5)+"-"+hasieraData.substring(6); // System.out.println(dataNorm); //
	 * System.out.println("WorkingDir:" + Main.getWorkingDirectory()); String
	 * backSlash = "'"; backSlash = backSlash.replace("'", "\\"); String command =
	 * "set output '" + Main.getWorkingDirectory() + backSlash + idGaixo + "-" +
	 * getHDataDB().replace(" ", "-").replace(":", "-") + "__" + label.replace(" ",
	 * "-") + ".png'"; // System.out.println(command); // command = "set output '" +
	 * Main.getWorkingDirectory() + backSlash // +label.replace(" ","_") + ".png'";
	 * p.getPostInit().add(command); // p.setParameters(par); //
	 * p.setKey(JavaPlot.Key.OFF); p.setKey(JavaPlot.Key.OFF); // p.set("label",
	 * "AAAAAAAAAA"); //
	 * p.getPostInit().add("set key right top Right title 'Legend' box 3"); //
	 * p.getPostInit().add("set y2label 'Y2Label'"); //
	 * p.getPostInit().add("set label 2 '5 meV' at 200,3000"); // p.set("xlabel",
	 * "'x'"); // stl2.set("set title 'test2'"); Datafile //
	 * stl2.set("set label 'test3'"); // p.setMultiTitle("Test"); //
	 * p.getPostInit().add("set key spacing 3"); //
	 * p.getPostInit().add("set key box lt -1 lw 2"); p.plot(); i++; } else {
	 * System.out.println("Doesn't contain label: " + label); }
	 * 
	 * }
	 * 
	 * }
	 * 
	 * public void rePlotByParamsHighlights(ArrayList<String> selectedParameters,
	 * int from, int to, String idGaixo) { // TODO Auto-generated method stub //
	 * TODO Auto-generated method stub // TODO Auto-generated method stub //
	 * System.out.println("Plotting by Params: " + selectedParameters); int i = 0;
	 * 
	 * for (String label : seinaleak.keySet()) { if
	 * (selectedParameters.contains(label)) { // System.out.println("Plotting: " +
	 * label);
	 * 
	 * JavaPlot p = new JavaPlot(); p.setTitle(label);
	 * 
	 * int[][] maxMin = getMaximumMinimum(label); // MaxMin[0][] = Maximum[] ||
	 * MaxMin[1][] = Minimum[] || // Maximum[0] = second, Maximum[1] = value int[][]
	 * fPlot = getValueSecondHighlights(label, maxMin[0][1], maxMin[1][1]); //
	 * fPlot[second][value]
	 * 
	 * /* y-coordinate, use "set size ratio." Suppose the x range is from -5 to 5
	 * that is a length of 10; the y range is from -1 to 1 that is a length of 2.
	 * The ratio between them should be y/x = 2/10 = 0.2. Therefore, you enter
	 * gnuplot> set size ratio 0.2 gnuplot> plot [-5:5][-1:1] sin(x)*cos(x**2)
	 */

	// testPlot
	/*
	 * fPlot = new int[10][1]; fPlot[0][0] = 1; fPlot[1][0] = 20; fPlot[2][0] = 22;
	 * fPlot[3][0] = 21; fPlot[4][0] = 20; fPlot[5][0] = 19; fPlot[6][0] = 15;
	 * fPlot[7][0] = 14; fPlot[8][0] = 13; fPlot[9][0] = 50;
	 */

	// DATA
	/*
	 * p.addPlot(fPlot); p.getAxis("x").setLabel("Tiempo (s)");
	 * p.getAxis("y").setLabel("Valor"); // + añadir medida en cuestion TODO
	 * 
	 * // p.getAxis("x").setBoundaries(0, 100); //
	 * p.getAxis("y").setBoundaries(-100,100); // System.out.println("maxi: " +
	 * maxMin[0][1] + "mini: " + maxMin[1][1]); maxMin[0][1] = getMax(fPlot);
	 * maxMin[1][1] = getMin(fPlot); // System.out.println("maxi: " + maxMin[0][1] +
	 * "mini: " + maxMin[1][1]);
	 * 
	 * p.getAxis("y").setBoundaries(maxMin[1][1] * 1.25, maxMin[0][1] * 1.25);
	 * 
	 * if (from > 0 && from < fPlot.length && to > 0 && to < fPlot.length) {
	 * p.getAxis("x").setBoundaries(from, to); // Caso bien } else if (from > 0 &&
	 * from < fPlot.length) { p.getAxis("x").setBoundaries(from, fPlot.length); //
	 * caso to no valido } else if (to > 0 && to < fPlot.length) {
	 * p.getAxis("x").setBoundaries(0, to); // Caso from no valido } else {
	 * p.getAxis("x").setBoundaries(0, fPlot.length); // el resto }
	 * 
	 * p.setKey(JavaPlot.Key.TOP_RIGHT); // p.set("Maximun/Minimum", "Values");
	 * 
	 * PlotStyle stl = ((AbstractPlot) p.getPlots().get(0)).getPlotStyle(); //
	 * tl.setStyle(Style.LINES); stl.setStyle(Style.LINES); // stl.setPointSize(1);
	 * // JavaPlot.getDebugger().setLevel(Debug.VERBOSE);
	 * stl.setLineType(NamedPlotColor.DARK_BLUE);
	 * 
	 * // MaxMins int[][] maxMinL = new int[seinaleak.get(label).size() + 1][1];
	 * maxMinL[maxMin[1][0]][0] = maxMin[1][1]; maxMinL[maxMin[0][0]][0] =
	 * maxMin[0][1];
	 * 
	 * p.addPlot(maxMinL);
	 * 
	 * PlotStyle stl2 = ((AbstractPlot) p.getPlots().get(1)).getPlotStyle(); //
	 * tl.setStyle(Style.LINES); // stl2.setStyle(Style.LINES);
	 * stl2.setStyle(Style.FSTEPS); stl2.setLineType(NamedPlotColor.LIGHT_RED); //
	 * stl2.setStyle(Style.POINTS); // stl2.setPointType(50); //
	 * stl2.setLineType(2); // stl2.setPointSize(20);
	 * 
	 * // Outputa terminal gisa bidaltzea aztertu
	 * 
	 * // par.set("output", "output.png"); 640, 1080 | 1920,1080 p.getPostInit().
	 * add("set terminal png size  1875,640 enhanced font \"Helvetica,20\""); //
	 * String dataNorm = hasieraData.substring(0, 2)+"-"+hasieraData.substring(3, //
	 * 5)+"-"+hasieraData.substring(6); // System.out.println(dataNorm); //
	 * System.out.println("WorkingDir:" + Main.getWorkingDirectory()); String
	 * backSlash = "'"; backSlash = backSlash.replace("'", "\\"); String command =
	 * "set output '" + Main.getWorkingDirectory() + backSlash + idGaixo + "-" +
	 * getHDataDB().replace(" ", "-").replace(":", "-") + "__" + label.replace(" ",
	 * "-") + "--Replot" + ".png'"; // System.out.println(command); // command =
	 * "set output '" + Main.getWorkingDirectory() + backSlash //
	 * +label.replace(" ","_") + ".png'"; p.getPostInit().add(command); //
	 * p.setParameters(par); // p.setKey(JavaPlot.Key.OFF);
	 * p.setKey(JavaPlot.Key.OFF); // p.set("label", "AAAAAAAAAA"); //
	 * p.getPostInit().add("set key right top Right title 'Legend' box 3"); //
	 * p.getPostInit().add("set y2label 'Y2Label'"); //
	 * p.getPostInit().add("set label 2 '5 meV' at 200,3000"); // p.set("xlabel",
	 * "'x'"); // stl2.set("set title 'test2'"); Datafile //
	 * stl2.set("set label 'test3'"); // p.setMultiTitle("Test"); //
	 * p.getPostInit().add("set key spacing 3"); //
	 * p.getPostInit().add("set key box lt -1 lw 2"); p.plot(); i++; } else {
	 * System.out.println("Doesn't contain label: " + label); }
	 * 
	 * } } public void plotByParamsOLD(ArrayList<String> params) { // TODO
	 * Auto-generated method stub // System.out.println("Plotting by Params: " +
	 * params); int i = 0;
	 * 
	 * for (String label : seinaleak.keySet()) { if (params.contains(label)) { //
	 * System.out.println("Plotting: " + label);
	 * 
	 * JavaPlot p = new JavaPlot(); p.setTitle(label);
	 * 
	 * int[][] maxMin = getMaximumMinimum(label); // MaxMin[0][] = Maximum[] ||
	 * MaxMin[1][] = Minimum[] || // Maximum[0] = second, Maximum[1] = value int[][]
	 * fPlot = getValueSecond(label); // fPlot[second][value]
	 * 
	 * /* y-coordinate, use "set size ratio." Suppose the x range is from -5 to 5
	 * that is a length of 10; the y range is from -1 to 1 that is a length of 2.
	 * The ratio between them should be y/x = 2/10 = 0.2. Therefore, you enter
	 * gnuplot> set size ratio 0.2 gnuplot> plot [-5:5][-1:1] sin(x)*cos(x**2)
	 */

	// testPlot
	/*
	 * fPlot = new int[10][1]; fPlot[0][0] = 1; fPlot[1][0] = 20; fPlot[2][0] = 22;
	 * fPlot[3][0] = 21; fPlot[4][0] = 20; fPlot[5][0] = 19; fPlot[6][0] = 15;
	 * fPlot[7][0] = 14; fPlot[8][0] = 13; fPlot[9][0] = 50;
	 */
	/*
	 * p.addPlot(fPlot); p.getAxis("x").setLabel("Tiempo (s)");
	 * p.getAxis("y").setLabel("Valor"); // + añadir medida en cuestion TODO
	 * p.getAxis("x").setBoundaries(0, fPlot.length); //
	 * p.getAxis("x").setBoundaries(0, 100); //
	 * p.getAxis("y").setBoundaries(-100,100); // System.out.println("maxi: " +
	 * maxMin[0][1] + "mini: " + maxMin[1][1]); maxMin[0][1] = getMax(fPlot);
	 * maxMin[1][1] = getMin(fPlot); // System.out.println("maxi: " + maxMin[0][1] +
	 * "mini: " + maxMin[1][1]);
	 * 
	 * p.getAxis("y").setBoundaries(maxMin[1][1] * 2, maxMin[0][1] * 2);
	 * p.setKey(JavaPlot.Key.TOP_RIGHT); // p.set("Maximun/Minimum", "Values");
	 * 
	 * PlotStyle stl = ((AbstractPlot) p.getPlots().get(0)).getPlotStyle(); //
	 * tl.setStyle(Style.LINES); stl.setStyle(Style.LINES); // stl.setPointSize(1);
	 * // JavaPlot.getDebugger().setLevel(Debug.VERBOSE);
	 * stl.setLineType(NamedPlotColor.DARK_BLUE); int[][] maxMinL = new
	 * int[seinaleak.get(label).size() + 1][1]; maxMinL[maxMin[1][0]][0] =
	 * maxMin[1][1]; maxMinL[maxMin[0][0]][0] = maxMin[0][1]; p.addPlot(maxMinL);
	 * 
	 * PlotStyle stl2 = ((AbstractPlot) p.getPlots().get(1)).getPlotStyle(); //
	 * tl.setStyle(Style.LINES); // stl2.setStyle(Style.LINES);
	 * stl2.setStyle(Style.FSTEPS); stl2.setLineType(NamedPlotColor.LIGHT_RED); //
	 * stl2.setStyle(Style.POINTS); // stl2.setPointType(50); //
	 * stl2.setLineType(2); // stl2.setPointSize(20);
	 * 
	 * // Outputa terminal gisa bidaltzea aztertu
	 * 
	 * // par.set("output", "output.png"); p.getPostInit().
	 * add("set terminal png size 1920,1080 enhanced font \"Helvetica,20\""); //
	 * String dataNorm = hasieraData.substring(0, 2)+"-"+hasieraData.substring(3, //
	 * 5)+"-"+hasieraData.substring(6); // System.out.println(dataNorm); //
	 * System.out.println("WorkingDir:" + Main.getWorkingDirectory()); String
	 * backSlash = "'"; backSlash = backSlash.replace("'", "\\"); String command =
	 * "set output '" + Main.getWorkingDirectory() + backSlash +
	 * getHDataDB().replace(" ", "-").replace(":", "-") + "__" + label.replace(" ",
	 * "-") + ".png'"; // System.out.println(command); // command = "set output '" +
	 * Main.getWorkingDirectory() + backSlash // +label.replace(" ","_") + ".png'";
	 * p.getPostInit().add(command); // p.setParameters(par); p.plot(); i++; } else
	 * { System.out.println("Doesn't contain label: " + label); }
	 * 
	 * }
	 * 
	 * }
	 * 
	 */
}

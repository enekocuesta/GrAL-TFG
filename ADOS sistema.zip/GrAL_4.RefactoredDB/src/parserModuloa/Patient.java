package parserModuloa;

//ALDAKETAK ENEKO
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import datuBasea.DbGalderak;
import datuBasea.DbKonexioa;
import edfParserUtils.EDFParser;
import edfParserUtils.EDFParserResult;
//TODO:

//QUITAR LOS OTROS GOIBURUS
//ORDENAR LOS MIOS
//PONER EL DATA
//DOKUMENTACION

public class Patient {
	// AURREKO PARAMETROAK
	private String idGaixo;
	// private Date jData;
	/*
	 * private String horaInicio; // todo el registro private String fechaInicio;
	 * private String horaInicioEstudio; // la que se considera para el estudio:
	 * mismo tiempo o menos que horaInicio private String fechaInicioEstudio;
	 * private String fechaFinEstudio; private String horaFinEstudio;
	 * 
	 * private Boolean alreadyHeader = false;
	 */
	// PARAMETRO BERRIAK (ENEKO)
	// HashMap<String, ArrayList<Object>> resultDATA = new HashMap<String,
	// ArrayList<Object>>();
	private ArrayList<Study> estudioList;

	// private ArrayList<String> paramList = null;
	// private ArrayList<String> dataList = null;
	public Patient(String pId) {
		idGaixo = pId;// .replace(" ", "");

		this.estudioList = new ArrayList<Study>();

		// System.out.println(pData);
		System.out.println("patient name: " + idGaixo);
		DbGalderak.sendUpdate("Insert into gaixoa kodea values("
				+ "'" + idGaixo + "'," +
				")");
		
	}

	public Patient(File edfFile) {

		idGaixo = getPatientName(edfFile);// .replace(" ", "");

		this.estudioList = new ArrayList<Study>();

		// System.out.println(pData);
		System.out.println("patient name: " + idGaixo);

	}

	private String getPatientName(File edfFile) {
		// TODO Auto-generated method stub
		/*
		String fullEDFPath = edfFile.toString();
		EDFParserResult result = null;
		File f = new File(fullEDFPath);
		InputStream is = null;

		// ERRORE TRATAERA AZKARRA
		try {
			is = new FileInputStream(f);
			result = EDFParser.parseEDF(is);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("PeriodListCreator.createPeriodList():: error fichero " + fullEDFPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("PeriodListCreator.createPeriodList():: error fichero " + fullEDFPath);
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		*/
		return edfFile.getName().split(".edf")[0].replaceAll(" ", "");
		//return fullEDFPath.split("\\")[fullEDFPath.split("\\").length]; 		
				//result.getHeader().getSubjectID().substring(0, 19);
	}

	public String getPatientId() {
		return idGaixo;
	}

	/*
	 * public void writeToFile(BufferedWriter pBw) throws IOException {
	 * if(!alreadyHeader) { //1.go labelak jarri for (String label :
	 * resultDATA.keySet()) {
	 * 
	 * pBw.write(label+";");
	 * 
	 * //for (short sh : resultDATA.keySet()) { // pBw.write(label+";"); // Object
	 * data = resultDATA.get(label).get(0); //} } alreadyHeader = true; }
	 * 
	 * 
	 * pBw.write("\n"); //Gero datuak //OHARRA: DATUAK GORDETZEKO EZ EGIN
	 * ORIZONTALKI BERTIKALKI BAIZIK for (String label : resultDATA.keySet()) {
	 * ArrayList<Object> balioak = resultDATA.get(label); idatziBalioSync(balioak,
	 * pBw, label); }
	 * 
	 * 
	 * 
	 * //pBw.write(idPaciente+";" +fechaInicio
	 * +";"+horaInicio+";"+fechaInicioEstudio+";" //
	 * +horaInicioEstudio+";"+fechaFinEstudio+";"+horaFinEstudio); }
	 * 
	 * private void idatziBalioSync(ArrayList<Object> balioak, BufferedWriter pBw,
	 * String label) throws IOException { //HOBE BALIOEN SYNK ZUZENEAN EDFtik
	 * HARTZEAN EGITEA ++ Hz erabiliz int indize = 0; //HZ int maiztasuna =
	 * lortuMaistazuna(balioak.size());
	 * System.out.println("Label: "+label+" || Hz: "+maiztasuna);
	 * 
	 * 
	 * //System.out.println("-----"+label+"-----"); for (Object balioa : balioak) {
	 * maiztasuna = 100; if(indize == maiztasuna) { //Balioa sartu ahal badu
	 * pBw.write(balioa.toString() +" ");
	 * //System.out.println("     "+balioa.toString()+"     "); indize = 0; }else {
	 * indize++; }
	 * 
	 * } pBw.write("|"); }
	 * 
	 * private int lortuMaistazuna(int size) {
	 * System.out.println("Ikasketa hasiera: "+ horaInicioEstudio);
	 * System.out.println("Ikasketa bukaera: "+ horaFinEstudio); //Orduak int hOrdua
	 * = Integer.parseInt(horaInicioEstudio.split(":")[0])*3600; int bOrdua =
	 * Integer.parseInt(horaFinEstudio.split(":")[0])*3600; //Minutuak int hMin =
	 * Integer.parseInt(horaInicioEstudio.split(":")[1])*60; int bMin =
	 * Integer.parseInt(horaFinEstudio.split(":")[1])*60; //Segunduak int hSeg =
	 * Integer.parseInt(horaInicioEstudio.split(":")[2]); int bSeg =
	 * Integer.parseInt(horaFinEstudio.split(":")[2]); //Luzeera int dOrdua =
	 * Math.abs(hOrdua-bOrdua); int dMin = Math.abs(hMin-bMin); int dSeg =
	 * Math.abs(hSeg-bSeg); int duration = dOrdua + dMin + dSeg;
	 * System.out.println("duration: "+ duration);
	 * System.out.println("Luzeera: "+size); int maiztasuna = size / duration;
	 * return maiztasuna; /* switch (label) { case "Abdomen": // 20Hz lagunSync =
	 * 20; break; case "Actividad": // 10Hz lagunSync = 20; break; case "Eje_X": //
	 * 10Hz lagunSync = 20; break; case "Eje_Y": // 10Hz lagunSync = 20; break; case
	 * "Eje_Z": // 10Hz lagunSync = 20; break; case "Elevación": // 10Hz lagunSync
	 * = 20; break; case "Fase RIP": // 1Hz lagunSync = 20; break; case "Flujo RIP":
	 * // 20Hz lagunSync = 20; break; case "Frec. Resp.": // 20Hz lagunSync = 20;
	 * break; case "Pletismógrafo": // 75Hz lagunSync = 20; break; case
	 * "Posición": // 10Hz lagunSync = 20; break; case "Pulso           ": // 3Hz
	 * lagunSync = 3; break; case "SpO2": // 3Hz lagunSync = 20; break; case
	 * "SpO2 B-B": // 3Hz lagunSync = 20; break; case "Suma RIP": // 20Hz lagunSync
	 * = 20; break; case "Temp": // 200Hz lagunSync = 20; break; case
	 * "Temp [FIR-LP: 8H": // 200Hz lagunSync = 20; break; case "Tórax": // 20Hz
	 * lagunSync = 20; break; case "Vol umen de Audio": // 20Hz lagunSync = 20;
	 * break; case "Vol umen de sonid": // 20Hz lagunSync = 20; break; default:
	 * lagunSync = 1; break; }
	 * 
	 * } /* public void actualizarInfoPaciente(String filePathEDF) { EDFParserResult
	 * result = null; File f = new File(filePathEDF); InputStream is = null;
	 * 
	 * //ERRORE TRATAERA AZKARRA try { is = new FileInputStream(f); result =
	 * EDFParser.parseEDF(is); } catch (FileNotFoundException e) { // TODO
	 * Auto-generated catch block e.printStackTrace();
	 * System.out.println("PeriodListCreator.createPeriodList():: error fichero "+
	 * filePathEDF); } catch (IOException e) { // TODO Auto-generated catch block
	 * e.printStackTrace();
	 * System.out.println("PeriodListCreator.createPeriodList():: error fichero "+
	 * filePathEDF); } finally { try { is.close(); } catch (IOException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } }
	 * 
	 * //DATUAK HARTZEN DITU CSVRA PASATZEKO //KODE BERRIA (ENEKO) //Goiburua
	 * idazten du fitxategian (channelLabels)
	 * 
	 * ArrayList<Object> idGaixo = new ArrayList<Object>();
	 * idGaixo.add(result.getHeader().getSubjectID());
	 * 
	 * ArrayList<Object> hData = new ArrayList<Object>();
	 * hData.add(result.getHeader().getStartDate());
	 * 
	 * ArrayList<Object> hOrdua = new ArrayList<Object>();
	 * hOrdua.add(result.getHeader().getStartTime());
	 * 
	 * ArrayList<Object> ghData = new ArrayList<Object>();
	 * ghData.add(result.getHeader().getStartDate());
	 * 
	 * ArrayList<Object> ghOrdua = new ArrayList<Object>(); ghOrdua.add(
	 * result.getHeader().getStartTime());
	 * 
	 * ArrayList<Object> gbData = new ArrayList<Object>();
	 * gbData.add(result.getHeader().getStartDate());
	 * 
	 * ArrayList<Object> gbOrdua = new ArrayList<Object>(); gbOrdua.add(
	 * result.getHeader().getStartTime());
	 * 
	 * resultDATA.put("idGaixo",idGaixo); resultDATA.put("Hasiera-Data", hData);
	 * resultDATA.put("Hasiera-Ordua", hOrdua);
	 * 
	 * resultDATA.put("Grabazio-Hasiera-Data", ghData);
	 * resultDATA.put("Grabazio-Hasiera-Ordua", ghOrdua);
	 * 
	 * 
	 * //parametro bakoitzeko int i = 0; ArrayList<Object> data = null; for (String
	 * label : result.getHeader().channelLabels) { data = new ArrayList<Object>();
	 * for(short value : result.getSignal().getDigitalValues()[i++]) {
	 * data.add(value); }
	 * 
	 * resultDATA.put(label,data); //parametro listan sartu
	 * 
	 * }
	 * 
	 * 
	 * 
	 * //bw.write("Id-paciente;Fecha-inicio;Hora-inicio;Fecha-inicio-estudio;" // +
	 * "Hora-inicio-estudio;Fecha-fin-estudio;Hora-fin-estudio\n");
	 * 
	 * //this.idPaciente = result.getHeader().getSubjectID(); //KODE ZAHARRA
	 * this.horaInicio = result.getHeader().getStartTime(); this.fechaInicio =
	 * result.getHeader().getStartDate(); this.horaInicioEstudio = horaInicio;
	 * this.fechaInicioEstudio = fechaInicio; //aparentemente son las mismas siempre
	 * 
	 * double numSegs = result.getHeader().getNumberOfRecords() *
	 * result.getHeader().getDurationOfRecords(); int nSegs = (int)
	 * Math.round(numSegs);
	 * 
	 * Calendar cal = Calendar.getInstance(); SimpleDateFormat sdf = new
	 * SimpleDateFormat("dd.MM.yy-HH.mm.ss"); try {
	 * cal.setTime(sdf.parse(fechaInicio + "-" + horaInicio));
	 * cal.add(Calendar.SECOND, nSegs); String formatted =
	 * sdf.format(cal.getTime()); String[] splitted = formatted.split("-");
	 * 
	 * this.fechaFinEstudio = splitted[0]; this.horaFinEstudio = splitted[1];
	 * 
	 * //Convertimos al formato que pide Juanma: 20/05/2000 --- 23:00:00
	 * 
	 * this.fechaInicio = this.fechaInicio.replace(".","/"); this.fechaInicioEstudio
	 * = this.fechaInicioEstudio.replace(".","/"); this.fechaFinEstudio =
	 * this.fechaFinEstudio.replace(".","/");
	 * 
	 * this.horaInicio = this.horaInicio.replace(".", ":"); this.horaInicioEstudio =
	 * this.horaInicioEstudio.replace(".", ":"); this.horaFinEstudio =
	 * this.horaFinEstudio.replace(".", ":"); gbData.add(fechaFinEstudio);
	 * gbOrdua.add(horaFinEstudio); resultDATA.put("Grabazio-Bukaera-Data", gbData);
	 * resultDATA.put("Grabazio-Bukaera-Ordua", gbOrdua); } catch (ParseException
	 * e1) { e1.printStackTrace(); System.out.
	 * println("Patient.actualizarInfo():: Problema al parsear las fechas/horas"); }
	 * 
	 * }
	 */

	public void addEstudioOld(String fullEDFPath) {
		// A�ade el estudio al paciente
		EDFParserResult result = null;
		File f = new File(fullEDFPath);
		InputStream is = null;

		// ERRORE TRATAERA AZKARRA
		try {
			is = new FileInputStream(f);
			result = EDFParser.parseEDF(is);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("PeriodListCreator.createPeriodList():: error fichero " + fullEDFPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("PeriodListCreator.createPeriodList():: error fichero " + fullEDFPath);
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// Kode zatia (coje los valores del edf y los a�ade al estudio)
		Study estudio = new Study();
		estudio.parseDataOld(result, idGaixo);
		estudioList.add(estudio);

		/*
		 * DbGalderak.send("INSERT INTO PROBA (gaKodea, pData, hData, bData) values("+
		 * idGaixo+","+estudio.getHDataDB()+","+estudio.getHDataDB()+","+estudio.
		 * getBDataDB()+ ")");
		 * 
		 */

		DbGalderak.sendUpdate("INSERT INTO PROBA (gaKodea, pData, hasiera, bukaera) values('" + idGaixo + "','"
				+ estudio.getHDataDB() + "','" + estudio.getHDataDB() + "','" + estudio.getBDataDB() + "')");

	}



	public void kargatuDb() {
		// TODO Auto-generated method stub
		ArrayList<ArrayList<String>> result = DbGalderak
				.sendWithReturnArray("Select * FROM PROBA where gaKodea ='" + idGaixo + "'");

		for (ArrayList<String> row : result) {
			Study s = new Study(row.get(1), row.get(3));
			estudioList.add(s);
		}
	}

	public void addEstudio(String fullEdfPath) {
		// TODO Auto-generated method stub
		// A�ade el estudio al paciente
		EDFParserResult result = null;
		File f = new File(fullEdfPath);
		InputStream is = null;

		// ERRORE TRATAERA AZKARRA
		try {
			is = new FileInputStream(f);
			result = EDFParser.parseEDF(is);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("PeriodListCreator.createPeriodList():: error fichero " + fullEdfPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("PeriodListCreator.createPeriodList():: error fichero " + fullEdfPath);
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// Kode zatia (coje los valores del edf y los a�ade al estudio)
		System.out.println("Creating study");
		Study estudio = new Study();
		System.out.println("Parsing edf data");
		estudio.parseData(result, idGaixo);
		estudioList.add(estudio);
		if(!DbGalderak.sendQuery("Select kodea from gaixoa where kodea = '"+idGaixo+"'")) {
			System.out.println("Insert into gaixoa (kodea) values("
					+ "'" + idGaixo + "'" +
					")");
			DbGalderak.sendUpdate("Insert into gaixoa (kodea) values("
					+ "'" + idGaixo + "'" +
					")");
		}
		if(!DbGalderak.sendQuery("Select gaKodea from proba where gaKodea = '"+idGaixo+"'"+"and pData='"+estudio.getHDataDB()+"'")) {
			System.out.println("Insert into proba values("
					+ "'" + idGaixo + "'," +
					"'" + estudio.getHDataDB() + "'," +
					"'" + estudio.getHDataDB() + "'," +
					"'" + estudio.getBDataDB() + "'" +
					")");
			DbGalderak.sendUpdate("Insert into proba values("
					+ "'" + idGaixo + "'," +
					"'" + estudio.getHDataDB() + "'," +
					"'" + estudio.getHDataDB() + "'," +
					"'" + estudio.getBDataDB() + "'" +
					")");
		}
		/*
		 * DbGalderak.send("INSERT INTO PROBA (gaKodea, pData, hData, bData) values("+
		 * idGaixo+","+estudio.getHDataDB()+","+estudio.getHDataDB()+","+estudio.
		 * getBDataDB()+ ")");
		 * 
		 */
	}

	public Study getStudio() { // Only one study so one return
		// TODO Auto-generated method stub
		return estudioList.get(0);
	}
	
	public void plotData() {
		// TODO Auto-generated method stub
		System.out.println("Paciente: " + idGaixo);
		for (Study s : estudioList) { // Por cada paciente
			s.plotData();
		}
	}
	public void plotByParams(ArrayList<String> params, boolean highlights) {
		// TODO hacer con datubase
		for (Study s : estudioList) {
			s.plotByParams(params, idGaixo,highlights);
		}
	}

	public void rePlotByParams(ArrayList<String> selectedParameters, String from, String to, boolean highlights) {
		// TODO Auto-generated method stub
		for (Study s : estudioList) {
			s.rePlotByParams(selectedParameters, Integer.parseInt(from), Integer.parseInt(to), idGaixo,highlights);
		}
	}
/*
	public void plotByParamsHighlights(ArrayList<String> selectedParameters) {
		// TODO Auto-generated method stub
		// TODO hacer con datubase
		for (Study s : estudioList) {
			s.plotByParamsHighlights(selectedParameters, idGaixo);
		}
	}

	public void rePlotByPicos(ArrayList<String> selectedParameters, String from, String to) {
		// TODO Auto-generated method stub
		for (Study s : estudioList) {
			s.rePlotByParamsHighlights(selectedParameters, Integer.parseInt(from), Integer.parseInt(to), idGaixo);
		}
	}
*/

	public void uploadPicos(ArrayList<String> selectedParameters) {
		// TODO Auto-generated method stub
		for (Study s : estudioList) {
			s.uploadPicos(this.getPatientId(),selectedParameters);
		}
	}

	public void uploadEvents(String patientId) {
		// TODO Auto-generated method stub
		for (Study s : estudioList) {
			s.uploadEvents(this.getPatientId());
		}
	}
}

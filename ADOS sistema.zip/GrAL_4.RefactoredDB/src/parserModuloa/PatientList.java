package parserModuloa;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import datuBasea.DbGalderak;
import datuBasea.DbKonexioa;

public class PatientList {

	private ArrayList<Patient> lista;

	public PatientList() {
		this.lista = new ArrayList<Patient>();

	}

	private Iterator<Patient> getIterador() {
		return lista.iterator();
	}

	public void addOld(Patient pPat) {
		lista.add(pPat);
		sortuGaixoa(pPat.getPatientId()); // datu basean sortzen du
	}

	public void add(Patient pPat) {
		lista.add(pPat);
	}
	/*
	 * public void writeToFile(String pOutputPath) {
	 * System.out.println("Creando fichero de pacientes " + pOutputPath);
	 * 
	 * BufferedWriter bw; File outputFile = new File(pOutputPath); Patient
	 * unPaciente; Iterator<Patient> itr = getIterador();
	 * 
	 * try { //IDEA = CREA UN CSV CON LAS ID SOLAMENTE, CREA UN CSV APARTE POR CADA
	 * PACIENTE LEE TODOS LOS PACIENTES bw = new BufferedWriter(new
	 * FileWriter(outputFile));
	 * //bw.write("Id-paciente;Fecha-inicio;Hora-inicio;Fecha-inicio-estudio;" // +
	 * "Hora-inicio-estudio;Fecha-fin-estudio;Hora-fin-estudio\n");
	 * 
	 * 
	 * //DatuBasea Sortu dbKonexioa db = new dbKonexioa(); db.sortuDB();
	 * //Datubasearen taulak sortu db.sortuTaula();
	 * 
	 * 
	 * while (itr.hasNext()) { unPaciente = itr.next(); unPaciente.writeToFile(bw);
	 * //System.out.println(unPaciente);
	 * //System.out.println(unPaciente.toString()); //System.out.println();
	 * db.beteGaixo(unPaciente.resultDATA.get("idGaixo").get(0).toString()); }
	 * 
	 * bw.close();
	 * 
	 * 
	 * } catch (IOException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } finally { } }
	 * 
	 * private void escribirLinea(BufferedWriter pBw, String pLinea) { try {
	 * pBw.write(pLinea + "\n"); } catch (IOException e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); } }
	 */

	public boolean contains(String id) { // TODO check en base de datos
		// Mira si existe un paciente con la id y ya esta en la lista

		String sql = "SELECT * FROM GAIXOA WHERE kodea='" + id + "'";
		boolean exists = DbGalderak.exists(sql);

		return exists;

		/*
		 * boolean contains = false; for (Patient p : lista) { if (p.getPatientId() ==
		 * id){ contains = true; } } return contains;
		 */
	}

	public void addEstudio(String id, String fullEDFPath) {
		// Le pide al paciente de una id concreta a�adir el estudio
		for (Patient p : lista) { // Por cada paciente
			if (p.getPatientId().equals(id) && !existsStudioDb(id)) { // Si coinciden las id's
				p.addEstudioOld(fullEDFPath); // A�ade el estudio
			}
		}

	}

	private boolean existsStudioDb(String id) {
		ArrayList<ArrayList<String>> result = DbGalderak
				.sendWithReturnArray("Select * from proba where gakodea='" + id + "' and pData='");
		return false;
	}

	public void sortuGaixoa(String idGaixo) {
		String sql = "INSERT INTO GAIXOA (kodea) VALUES ('" + idGaixo + "');";
		DbGalderak.sendUpdate(sql);
	}

	public void kargatuDb() { // Soilik kodeak kargatzen ditu
		// Galdera datu baseari
		ArrayList<ArrayList<String>> result = DbGalderak.sendWithReturnArray("Select * FROM GAIXOA");
		for (ArrayList<String> row : result) {
			Patient p = new Patient(row.get(0));
			p.kargatuDb();
			lista.add(p);
		}
		/*
		 * ArrayList<String> rs = DbGalderak.sendWithReturn("SELECT * FROM GAIXOA"); try
		 * { if (rs != null) { while(rs.next()) { rs.next(); // moves cursor to the last
		 * row System.out.println(rs.getString(0)); } }else {
		 * System.out.println("Couldn't load database"); } }catch(SQLException e) {
		 * e.printStackTrace(); }
		 */

	}

	public void plotData() {
		// TODO Auto-generated method stub
		for (Patient p : lista) { // Por cada paciente
			p.plotData();
		}
	}

	public Patient getPatient(String patientId) {
		// TODO Auto-generated method stub
		for (Patient p : lista) {
			System.out.println(patientId + " = " + p.getPatientId());
			if (patientId.equals(p.getPatientId())) {
				return p;
			}
		}
		return null;
	}

	public Study previewRawData(String patientId) {
		// TODO Auto-generated method stub
		return getPatient(patientId).getStudio();
	}

	public void plotByParams(String patientId, ArrayList<String> params,boolean highlights) { // TODO version datubase que lo haga con el
																			// nombre del estudio
		for (Patient p : lista) { // Por cada paciente
			if (p.getPatientId().equals(patientId)) {
				p.plotByParams(params,highlights);
			}

		}

	}

	public void rePlotByParams(String patientId, ArrayList<String> selectedParameters, String from, String to,boolean highlights) {
		// TODO Auto-generated method stub
		for (Patient p : lista) { // Por cada paciente
			if (p.getPatientId().equals(patientId)) {
				p.rePlotByParams(selectedParameters, from, to,highlights);
			}

		}
	}

	public void uploadPicos(String name, ArrayList<String> selectedParameters) {
		// TODO Auto-generated method stub
		for (Patient p : lista) { // Por cada paciente
			if (p.getPatientId().equals(name)) {
				p.uploadPicos(selectedParameters);
			}

		}
	}

	public void uploadEvents(String patientId) {
		// TODO Auto-generated method stub
		for (Patient p : lista) { // Por cada paciente
			if (p.getPatientId().equals(patientId)) {
				p.uploadEvents(patientId);
			}

		}
	}
	
	
	/*
	 * public void plotByParamsHighlights(String patientId, ArrayList<String>
	 * selectedParameters) { // TODO Auto-generated method stub for (Patient p :
	 * lista) { //Por cada paciente if (p.getPatientId().equals(patientId)){
	 * p.plotByParamsHighlights(selectedParameters); }
	 * 
	 * } }
	 */
	/*
	 * public void rePlotByPicos(String patientId, ArrayList<String>
	 * selectedParameters, String from, String to) { // TODO Auto-generated method
	 * stub // TODO Auto-generated method stub for (Patient p : lista) { //Por cada
	 * paciente if (p.getPatientId().equals(patientId)){
	 * p.rePlotByPicos(selectedParameters,from,to); }
	 * 
	 * } }
	 */
}
